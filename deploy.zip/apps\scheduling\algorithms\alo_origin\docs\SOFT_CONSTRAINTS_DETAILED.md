# So Sánh Chi Tiết: Lecture Consecutiveness vs Curriculum Compactness

## 1. CURRICULUM COMPACTNESS (S3 - Đã Implement ✅)

### Định Nghĩa
**Curriculum Compactness** kiểm tra các **buổi học của một CURRICULUM** (nhóm môn học) trên **cùng 1 ngày**.

### Logic
- **Mức độ kiểm tra:** Curriculum → Ngày → Tiết học
- **Định nghĩa "Isolated":** 1 buổi học của curriculum bị cô lập nếu nó **KHÔNG có buổi học khác cạnh bên** (cùng curriculum, cùng ngày)

### Ví Dụ Cụ Thể

```
Curriculum "Lập trình C" có 3 lớp: C001, C002, C003

Scenario 1: ❌ VIOLATION (Isolated)
┌─────────────────────────────────────┐
│ T2 (Thứ 2):                         │
├─────────────────────────────────────┤
│ Ca 1: C001 (Lập trình C - LT)       │  ← ISOLATED (không có cạnh bên)
│ Ca 2: [TRỐNG]                       │  (không có ca 2, không có ca 0)
│ Ca 3: [TRỐNG]                       │
│ Ca 4: [TRỐNG]                       │
│ Ca 5: C002 (Lập trình C - LT)       │  ← ISOLATED (không có ca 4, ca 6)
└─────────────────────────────────────┘
Cost: +2 (hai buổi học bị cô lập)

Scenario 2: ✅ OK (Không Isolated)
┌─────────────────────────────────────┐
│ T2 (Thứ 2):                         │
├─────────────────────────────────────┤
│ Ca 1: C001 (Lập trình C - LT)       │  ← OK (có C002 ở ca 2)
│ Ca 2: C002 (Lập trình C - LT)       │  ← OK (có C001 ở ca 1)
│ Ca 3: [TRỐNG]                       │
│ Ca 4: [TRỐNG]                       │
│ Ca 5: C003 (Lập trình C - LT)       │  ← ISOLATED (không có ca 4, ca 6)
└─────────────────────────────────────┘
Cost: +1 (một buổi học bị cô lập)

Scenario 3: ✅ BEST (Tối Ưu)
┌─────────────────────────────────────┐
│ T2 (Thứ 2):                         │
├─────────────────────────────────────┤
│ Ca 1: C001 (Lập trình C - LT)       │  ← OK (có C002 ở ca 2)
│ Ca 2: C002 (Lập trình C - LT)       │  ← OK (có C003 ở ca 3)
│ Ca 3: C003 (Lập trình C - LT)       │  ← OK (có C002 ở ca 2)
│ Ca 4: [TRỐNG]                       │
│ Ca 5: [TRỐNG]                       │
└─────────────────────────────────────┘
Cost: 0 (không có violation)
```

### Công Thức Tính
```python
def costs_on_curriculum_compactness(self) -> int:
    cost = 0
    for curriculum in curricula:
        for day in days:
            for period in periods_of_day:
                if curriculum has lecture at period:
                    # Kiểm tra xem period này có buổi học cạnh bên không?
                    if (period-1) not in curriculum_periods AND (period+1) not in curriculum_periods:
                        cost += 1  # Buổi này bị isolated
    return cost
```

### Trọng Số (Weight)
- **Cost multiplier:** 2 (mỗi buổi isolated = 2 điểm penalty)
- `total_cost += costs_on_curriculum_compactness() * 2`

### Tại Sao Quan Trọng?
- **Mục đích:** Tập trung các buổi học của cùng 1 môn thành **khối học liên tiếp**
- **Lợi ích:** Giúp sinh viên có thời gian làm bài tập, ôn tập giữa các buổi học
- **Ví dụ:** Toán học 3 buổi/tuần → xếp liên tiếp (T2, T3, T4) tốt hơn (T2, T4, T6 rời rạc)

---

## 2. LECTURE CONSECUTIVENESS (S5 - Chưa Implement ⏳)

### Định Nghĩa
**Lecture Consecutiveness** kiểm tra các **buổi học của một COURSE** (môn học cụ thể) theo **mô hình xếp tiết học**:
- **2 tiết:** Phải xếp thành **1 cặp liên tiếp** (cùng ngày, slot kề nhau)
- **3 tiết:** Phải có **1 cặp + 1 buổi rời**, trên **≥ 2 ngày khác nhau**
- **4 tiết:** Phải có **2 cặp**, trên **≥ 2 ngày khác nhau**
- **≥ 5 tiết:** Phải có **≥ 2 cặp**, phân tán trên **≥ 2 ngày**

### Logic
- **Mức độ kiểm tra:** Course → Ngày → Cặp tiết liên tiếp (consecutive pairs)
- **Định nghĩa "Cặp":** 2 tiết kề nhau (slot n và slot n+1)
- **Mục tiêu:** Tối ưu hóa mô hình xếp tiết học của trường phổ thông Việt Nam

### Ví Dụ Cụ Thể

```
Course "Toán học" có 4 buổi/tuần

Scenario 1: ❌ VIOLATION (Không có cặp, phân tán quá)
┌─────────────────────────────────────┐
│ Toán - 4 tiết, không cặp nào        │
├─────────────────────────────────────┤
│ T2 Ca 1: Toán                        │
│ T3 Ca 3: Toán                        │
│ T4 Ca 2: Toán                        │
│ T5 Ca 4: Toán                        │
└─────────────────────────────────────┘
Cost: HIGH (4 tiết không theo pattern)

Scenario 2: ⚠️ PARTIAL (1 cặp, 2 buổi rời)
┌─────────────────────────────────────┐
│ Toán - 4 tiết, 1 cặp + 2 rời        │
├─────────────────────────────────────┤
│ T2 Ca 1: Toán ─┐                    │
│ T2 Ca 2: Toán ─┘ (Cặp 1)            │
│ T4 Ca 1: Toán     (Rời)             │
│ T5 Ca 3: Toán     (Rời)             │
└─────────────────────────────────────┘
Cost: MEDIUM (đạt 1/2 cặp yêu cầu)

Scenario 3: ✅ OK (2 cặp, phân tán)
┌─────────────────────────────────────┐
│ Toán - 4 tiết, 2 cặp                │
├─────────────────────────────────────┤
│ T2 Ca 1: Toán ─┐                    │
│ T2 Ca 2: Toán ─┘ (Cặp 1)            │
│ T4 Ca 3: Toán ─┐                    │
│ T4 Ca 4: Toán ─┘ (Cặp 2)            │
└─────────────────────────────────────┘
Cost: 0 (đạt mục tiêu)

Scenario 4: ✅ OK (2 tiết thành cặp)
┌─────────────────────────────────────┐
│ Toán - 2 tiết, 1 cặp                │
├─────────────────────────────────────┤
│ T2 Ca 2: Toán ─┐                    │
│ T2 Ca 3: Toán ─┘ (Cặp 1)            │
└─────────────────────────────────────┘
Cost: 0 (1 cặp = OK cho 2 tiết)
```

### Công Thức Tính (Pseudo Code)
```python
def costs_on_lecture_consecutiveness(self) -> int:
    cost = 0
    for course in courses:
        lectures = get_all_lectures_of_course(course)
        num_lectures = len(lectures)
        
        # Tìm cặp tiết liên tiếp
        pairs_count = count_consecutive_pairs(lectures)
        
        # Kiểm tra pattern yêu cầu
        if num_lectures == 2:
            if pairs_count < 1: cost += penalty
        elif num_lectures == 3:
            if pairs_count < 1: cost += penalty
            # Kiểm tra phân tán ≥ 2 ngày
        elif num_lectures == 4:
            if pairs_count < 2: cost += penalty
        else:  # ≥ 5
            if pairs_count < 2: cost += penalty
    
    return cost
```

### Trọng Số (Weight)
- **Chưa xác định** (NOT IMPLEMENTED YET)
- Tạm định: ~1 điểm/violation

### Tại Sao Quan Trọng?
- **Mục đích:** Tuân thủ quy tắc xếp tiết học của trường phổ thông
- **Lợi ích:** 
  - Tối ưu hóa thời khóa biểu (không xếp 4 tiết cùng ngày = quá tải)
  - Thuận tiện cho giáo viên (không phải lặp lại giáo án quá many times)
- **Ví dụ:** Tiếng Anh 4 tiết/tuần → xếp 2 cặp (T2 tiết 1-2, T5 tiết 3-4) tốt hơn (T2, T3, T4, T5 từng tiết)

---

## 3. So Sánh Bảng (Quick Reference)

| Tiêu Chí | Curriculum Compactness | Lecture Consecutiveness |
|----------|----------------------|----------------------|
| **Mức độ kiểm tra** | Curriculum → Ngày | Course → Toàn tuần |
| **Đơn vị** | Buổi học (lecture) | Cặp tiết liên tiếp |
| **"Tốt" là gì?** | Buổi học kế nhau (cạnh bên) | Cặp tiết kế nhau (cùng ngày) |
| **"Xấu" là gì?** | Buổi học cô lập (không cạnh bên) | Không đủ cặp hoặc phân tán quá |
| **Ví dụ tối ưu** | C001 T2 ca 1-2, C002 T2 ca 3-4 | Toán T2 ca 1-2, T4 ca 3-4 |
| **Ví dụ vi phạm** | C001 T2 ca 1, C002 T2 ca 5 (cô lập) | Toán T2, T3, T4, T5 (no pairs) |
| **Trạng thái** | ✅ IMPLEMENTED | ⏳ NOT YET |
| **Cost Weight** | 2 điểm/isolation | ~1 điểm/violation (tạm) |
| **Phạm vi** | Toàn bộ curriculum | Từng course riêng lẻ |

---

## 4. Lý Do Tại Sao Chưa Implement Lecture Consecutiveness

1. **Phức tạp**: Cần tracking tất cả periods của mỗi course → tìm cặp → tính pattern
2. **Quy tắc CỘI**: Mô hình 2-3-4-5+ tiết khác nhau → logic if-else phức tạp
3. **Trạng thái**: `validator.py` là **read-only validator**, không sắp xếp
4. **Ưu tiên**: Curriculum Compactness đã đạt mục tiêu chính (tập trung buổi học cùng môn)

---

## 5. Tóm Tắt

```
┌────────────────────────────────────────────────────────────────────┐
│ CURRICULUM COMPACTNESS (✅ Đã Implement)                          │
├────────────────────────────────────────────────────────────────────┤
│ Kiểm tra: Các buổi học của CÙNG 1 CURRICULUM có kế nhau không?   │
│ Mục tiêu: Tập trung các môn học cùng 1 chuyên ngành              │
│ Tính toán: Đếm buổi học bị ISOLATED (không có cạnh bên)          │
│ Penalty: 2 điểm/buổi isolated                                     │
└────────────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────────────┐
│ LECTURE CONSECUTIVENESS (⏳ Chưa Implement)                        │
├────────────────────────────────────────────────────────────────────┤
│ Kiểm tra: Các tiết học của CÙNG 1 COURSE có cặp liên tiếp không? │
│ Mục tiêu: Tuân thủ quy tắc xếp tiết học (2-3-4-5+ tiết/tuần)     │
│ Tính toán: Đếm cặp tiết liên tiếp → so với pattern yêu cầu       │
│ Penalty: ~1 điểm/pattern violation (tạm định)                     │
└────────────────────────────────────────────────────────────────────┘
```

---

## 6. Khi Nào Cần Implement Lecture Consecutiveness?

- ✅ Nếu trường CÓ yêu cầu strict về pattern xếp tiết học
- ⏳ Hiện tại: Curriculum Compactness đã đáp ứng phần lớn yêu cầu
- 📝 Để implement: Cần thêm hàm `_compute_course_consecutiveness_penalty()` vào `algo_new.py`
