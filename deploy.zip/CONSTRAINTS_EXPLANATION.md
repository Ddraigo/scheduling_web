# Giải Thích Các Ràng Buộc Trong algo_new.py

## Tổng Quan

`algo_new.py` là một scheduler sử dụng **Tabu Search** kết hợp với **Constraint Propagation** để giải bài toán xếp lịch học theo chuẩn ITC-2007 Track 3 (Curriculum-Based Course Timetabling - CB-CTT).

Các ràng buộc được kiểm tra trong hàm `_can_place()` (line 786-844):

---

## 8 Ràng Buộc Chính

### **Check 1: Period Availability (Tính Khả Dụng Thời Gian Slot)**
```python
if period in self.instance.unavailability[course_idx]:
    return False
```
**Logic:**
- Kiểm tra xem giáo viên có bận vào slot này không
- Nếu slot nằm trong danh sách `unavailability` của khóa học → **Không thể xếp**

**Loại:** HARD CONSTRAINT (vi phạm → không lập được lịch)

**Ví dụ:** GV001 không thể dạy T2 ca 1 → không xếp khóa học GV001 vào slot này

---

### **Check 2: Room Not Already Booked (Phòng Chưa Có Khóa Học Khác)**
```python
if room_idx in self.period_rooms[period]:
    return False
```
**Logic:**
- Một phòng chỉ có thể có **1 buổi học** trong **1 slot**
- `self.period_rooms[period]` = tập hợp các phòng đã được xếp vào slot này
- Nếu phòng đã có khóa học khác → **Không thể xếp**

**Loại:** HARD CONSTRAINT (vi phạm → lỗi)

**Ví dụ:** Phòng A401 đã có khóa học C001 vào T2 ca 1 → không xếp C002 vào A401 T2 ca 1

---

### **Check 3: Teacher Conflict (Giáo Viên Không Trùng Lịch)**
```python
teacher = self.instance.course_teachers[course_idx]
owner = self.period_teacher_owner[period].get(teacher)
if owner is not None and owner != lecture_id:
    return False
```
**Logic:**
- Một giáo viên chỉ dạy **1 khóa học** tại **1 slot**
- `self.period_teacher_owner[period]` = từ điển {GV_ID → lecture_id đang dạy ở slot này}
- Nếu GV này đã dạy khóa học khác ở slot này → **Không thể xếp**

**Loại:** HARD CONSTRAINT (vi phạm → lỗi)

**Ví dụ:** GV001 dạy C001 T2 ca 1 → không xếp C002 (dạy bởi GV001) vào T2 ca 1

---

### **Check 4: Curriculum Conflict (Curriculum Không Trùng Lịch)**
```python
for curriculum_idx in self.instance.course_curriculums[course_idx]:
    owner = self.period_curriculum_owner[period].get(curriculum_idx)
    if owner is not None and owner != lecture_id:
        return False
```
**Logic:**
- Các khóa học trong **cùng 1 Curriculum** (môn học) không thể xếp ở **cùng 1 slot**
- Mục đích: Tránh sinh viên bị conflict (không thể tham gia 2 lớp cùng lúc)
- `self.period_curriculum_owner[period]` = từ điển {curriculum_id → lecture_id ở slot này}
- Nếu curriculum này đã có khóa học khác ở slot này → **Không thể xếp**

**Loại:** HARD CONSTRAINT (vi phạm → lỗi)

**Ví dụ:** 
- Curriculum "Lập trình C" có 6 lớp (C001-C006)
- C001 xếp T2 ca 1 → C002-C006 không thể xếp T2 ca 1 (vì cùng curriculum)

---

### **Check 5: Room Capacity (Sức Chứa Phòng)**
```python
course = self.instance.courses[course_idx]
room = self.instance.rooms[room_idx]
if room.capacity < course.students:
    return False
```
**Logic:**
- Phòng phải có sức chứa **≥ số sinh viên** của khóa học
- `course.students` = số sinh viên trong lớp
- `room.capacity` = sức chứa tối đa của phòng
- Nếu sức chứa không đủ → **Không thể xếp**

**Loại:** HARD CONSTRAINT (vi phạm → lỗi)

**Ví dụ:** Lớp C001 có 80 sinh viên, phòng A401 chỉ chứa 60 → không xếp C001 vào A401

---

### **Check 6: Room Type Matching (Loại Phòng Phù Hợp)**
```python
if course.course_type != room.room_type:
    return False
```
**Logic:**
- **LT (Lý Thuyết)** courses → chỉ xếp vào **LT rooms**
- **TH (Thực Hành)** courses → chỉ xếp vào **TH rooms**
- Mục đích: Đảm bảo cơ sở vật chất phù hợp (bảng phấn vs thiết bị thực hành)

**Loại:** HARD CONSTRAINT (vi phạm → lỗi)

**Ví dụ:**
- Khóa học "Lập trình C thực hành" (type=TH) → phải xếp vào phòng máy (TH room)
- Khóa học "Toán giải tích" (type=LT) → có thể xếp vào phòng thường (LT room)

---

### **Check 7: Equipment Requirements (Yêu Cầu Thiết Bị)**
```python
# ⚠️ TEMPORARILY DISABLED - Equipment too restrictive
# if course.equipment:
#     room_equipment = room.equipment or ""
#     required_equipment = set(eq.strip() for eq in course.equipment.split(',') if eq.strip())
#     room_equipment_set = set(eq.strip() for eq in room_equipment.split(',') if eq.strip())
#     
#     if not required_equipment.issubset(room_equipment_set):
#         return False
```
**Logic:**
- Nếu khóa học yêu cầu thiết bị (TV, máy chiếu, ...) → phòng phải có thiết bị đó
- Parse equipment từ string dạng "TV, Máy chiếu" thành set
- Kiểm tra `required_equipment ⊆ room_equipment_set`

**Loại:** HARD CONSTRAINT (hiện tại bị DISABLED vì quá hạn chế)

**Trạng thái:** 🔴 **DISABLED** - Có thể kích hoạt sau nếu cần

**Ví dụ:**
- Khóa học yêu cầu "TV, Máy chiếu"
- Phòng chỉ có "Máy chiếu" → không xếp được (thiếu TV)
- Phòng có "TV, Máy chiếu, Bảng trắng" → xếp được (có đầy đủ)

---

### **Check 8: Teacher Preferences (Nguyện Vọng Giáo Viên) - SORT CONSTRAINT 🎯**
```python
# ✅ NOW ENABLED - Teacher Preferences enforced with highest priority
preferred_periods = self.instance.teacher_preferred_periods.get(teacher, set())
if preferred_periods and period not in preferred_periods:
    # GV có nguyện vọng nhưng period này không nằm trong đó → không thể xếp
    return False
```
**Logic:**
- Nếu giáo viên có **nguyện vọng** (preferred_periods) → chỉ xếp vào các slot đó
- `teacher_preferred_periods[teacher_id]` = set các slot mà GV muốn dạy
- Nếu slot không nằm trong danh sách nguyện vọng → **Không thể xếp**

**Loại:** SORT CONSTRAINT ⭐ (ưu tiên cao nhất)
- **Mục đích chính:** Đáp ứng nguyện vọng của giáo viên (tối ưu hóa hài lòng)
- **Hard constraint:** Được enforce trước tất cả các constraints khác
- **Relaxable constraint:** Nếu không thể tạo giải pháp khả thi → có thể relax bằng `_can_place_relaxed(relax_preference=True)`

**Trạng thái:** ✅ **ENABLED** - Được enforce với ưu tiên cao nhất

**Ví dụ:**
- GV001 nguyện vọng: T2 ca 1, T3 ca 2, T4 ca 3
- Xếp GV001 vào T2 ca 1 ✅ (có trong nguyện vọng - tối ưu)
- Xếp GV001 vào T5 ca 1 ❌ (không trong nguyện vọng - bị reject)

**Khi Nào Relax:**
- Nếu giáo viên có tất cả 5 lớp nhưng chỉ có 3 slot nguyện vọng → phải xếp 2 lớp ngoài nguyện vọng
- Nếu không relax → không thể tạo giải pháp khả thi
- Để debugging: sử dụng `_can_place_relaxed(lecture_id, period, room, relax_preference=True)` để bỏ qua check này

**Thứ Tự Ưu Tiên Trong `_can_place()`:**
```
1. Check 8: Teacher Preferences (SORT CONSTRAINT - ưu tiên 1)
   ↓
2. Check 1-7: Other hard constraints (ưu tiên 2-7)
```

---

## Bảng Tóm Tắt

| # | Constraint | Kiểm Tra | Trạng Thái | Ưu Tiên | Ghi Chú |
|---|-----------|---------|----------|---------|--------|
| 8 | Teacher Preferences | GV có nguyện vọng? | ✅ ENABLED | 🎯 **1** | Sort Constraint |
| 1 | Period Availability | GV bận? | ✅ ENABLED | 2 | Hard |
| 2 | Room Booking | Phòng trống? | ✅ ENABLED | 2 | Hard |
| 3 | Teacher Conflict | GV trùng lịch? | ✅ ENABLED | 2 | Hard |
| 4 | Curriculum Conflict | Curriculum trùng? | ✅ ENABLED | 2 | Hard |
| 5 | Room Capacity | Phòng đủ chỗ? | ✅ ENABLED | 2 | Hard (HC-03) |
| 6 | Room Type | Loại phòng phù hợp? | ✅ ENABLED | 2 | Hard (HC-05/06) |
| 7 | Equipment | Có thiết bị yêu cầu? | 🔴 DISABLED | 2 | Hard (HC-04 Extended) |

---

## Soft Constraints (Các Ràng Buộc Mềm)

Các ràng buộc này được tính **cost** thay vì bị reject:

### **S1: Room Capacity (Mềm)**
- Nếu phòng nhỏ hơn số sinh viên → tính cost = (students - capacity)
- Sự khác biệt với Check 5: S1 cho phép dùng phòng nhỏ nhưng phạt, Check 5 reject hoàn toàn

### **S2: Minimum Working Days**
- Mỗi khóa học phải nằm trên ≥ min_working_days ngày khác nhau
- Cost = (min_wd - actual_working_days) × MIN_WORKING_DAYS_COST

### **S3: Curriculum Compactness**
- Các khóa học trong cùng curriculum nên gần nhau (không cách quãng)
- Cost = count(isolated lectures) × CURRICULUM_COMPACTNESS_COST
- "Isolated" = buổi học của curriculum không có buổi khác của curriculum trước/sau nó trên cùng ngày

### **S4: Room Stability**
- Mỗi khóa học nên dùng **1 phòng** duy nhất (không thay đổi phòng)
- Cost = (rooms_used - 1) × ROOM_STABILITY_COST

---

## Cách Hoạt Động Của `_can_place()`

```
_can_place(lecture_id, period, room_idx) ?
    ├─ Check 8: Teacher Preference (ưu tiên cao nhất)? → NO → return False ⭐
    ├─ Check 1: Period available? → NO → return False
    ├─ Check 2: Room free? → NO → return False
    ├─ Check 3: Teacher available? → NO → return False
    ├─ Check 4: Curriculum conflict? → NO → return False
    ├─ Check 5: Room capacity OK? → NO → return False
    ├─ Check 6: Room type match? → NO → return False
    ├─ Check 7: Equipment OK? (DISABLED) → skip
    └─ return True (có thể xếp)
```

**Điều này có nghĩa:** 
- **Ưu tiên 1:** Nếu GV có nguyện vọng nhưng slot không nằm trong đó → **không thể xếp** (reject ngay)
- **Ưu tiên 2-7:** Nếu bất kỳ hard constraint khác fail → **không thể xếp**

### **Debugging: `_can_place_relaxed()`**

Nếu algorithm không tìm được giải pháp, có thể debug bằng:
```python
# Test xem có thể xếp không nếu bỏ qua teacher preferences
relaxed_ok = state._can_place_relaxed(lecture_id, period, room_idx, relax_preference=True)
```

Nếu `_can_place_relaxed(relax_preference=True)` trả về True nhưng `_can_place()` trả về False → **Teacher Preferences là nguyên nhân**

---

## Vì Sao Algorithm Không Tạo Được Giải Pháp Ban Đầu?

Dựa trên analysis trước:

1. **Check 4 (Curriculum Conflict) quá hạn chế:**
   - 48 curriculum với 216 khóa học
   - Một số curriculum chỉ có 1-2 giáo viên nhưng 3-4 lớp
   - Giáo viên có 3-4 lớp cùng curriculum → chỉ có 2 slot tối đa trên cùng ngày
   - Constraint propagation quá mạnh → không tìm được slot hợp lệ

2. **Check 6 (Room Type) là thắc mắc lớn:**
   - 126 TH courses vs 108 TH rooms
   - Có thể thiếu TH rooms nếu overlap cao

**Giải pháp:** 
- ✅ Tăng time_limit
- ✅ Disable Check 7 hoặc Check 8 tạm thời
- ⚠️ Relax room type matching (nếu cần)
- ⚠️ Thay đổi curriculum grouping

---

## Các Tệp Liên Quan

- **`validator.py`** - Kiểm tra và tính cost của lịch đã xếp
- **`convert_db_to_ctt.py`** - Chuyển DB → format .ctt (có room type, equipment)
- **`convert_db_to_ctt_ITC.py`** - Chuyển DB → format .ctt chuẩn ITC-2007
- **`dot1.ctt`** - Input instance (format mở rộng)
- **`dot_ITC.ctt`** - Input instance (format chuẩn ITC)
- **`test_2.sol`** - Output solution file (format: course room day period)
