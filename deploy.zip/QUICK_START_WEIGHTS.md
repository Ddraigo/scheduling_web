# Quick Start: Sử Dụng Dynamic Weights

## Bước 1: Seed Data (CHỈ LÀM MỘT LẦN)

```bash
python manage.py shell
```

```python
from apps.scheduling.migrations.seed_rang_buoc_mem import seed_rang_buoc_mem
seed_rang_buoc_mem()
exit()
```

**Kết quả:**
```
✅ Created: RB_MIN_WORKING_DAYS - ... (weight=1.0)
✅ Created: RB_TEACHER_PREFERENCE - ... (weight=2.0)
...
📊 Summary: Created=7, Updated=0
```

---

## Bước 2: Sử Dụng Trong Code

### Cách Cũ (Hardcoded):
```python
from apps.scheduling.algorithms.algorithms_core import TimetableState, parse_instance

instance = parse_instance("input.txt")
state = TimetableState(instance)  # ❌ Dùng trọng số cố định
```

### Cách Mới (Dynamic):
```python
from apps.scheduling.algorithms.algorithms_core import TimetableState, parse_instance

instance = parse_instance("input.txt")
state = TimetableState(instance, ma_dot='DOT-2024-HK1')  # ✅ Load từ database
```

**Chỉ thêm 1 parameter `ma_dot`!**

---

## Bước 3: Thay Đổi Trọng Số (Qua Admin)

### Scenario A: Thay đổi global (áp dụng cho tất cả các đợt)

1. Vào `http://localhost:8000/admin/scheduling/rangbuocmem/`
2. Click vào constraint muốn sửa (ví dụ: `RB_TEACHER_PREFERENCE`)
3. Sửa `TrongSo` (ví dụ: 2.0 → 3.0)
4. Click **Save**

**Xong!** Solver sẽ dùng trọng số mới ngay lập tức.

### Scenario B: Override cho đợt cụ thể

1. Vào `http://localhost:8000/admin/scheduling/rangbuoctrongdot/add/`
2. Chọn `MaDot` (ví dụ: DOT-2024-HK1)
3. Chọn `MaRangBuoc` (ví dụ: RB_TEACHER_PREFERENCE)
4. Click **Save**

**Lưu ý**: Chỉ thêm những ràng buộc muốn override. Còn lại dùng global defaults.

---

## Test

```bash
python -m apps.scheduling.algorithms.test_weight_loader
```

**Kết quả mong đợi:**
```
############################################################
# ALL TESTS PASSED ✅
############################################################
```

---

## Verify Weights

```python
from apps.scheduling.algorithms.weight_loader import WeightLoader

# Load weights cho đợt
weights = WeightLoader.load_weights('DOT-2024-HK1')
print(weights)

# Output:
# {
#     'MIN_WORKING_DAYS': 1.0,
#     'TEACHER_PREFERENCE': 2.0,
#     'LECTURE_CONSECUTIVENESS': 1.5,
#     ...
# }
```

---

## Nếu Database Trống?

**Không sao!** Hệ thống tự động fallback sang DEFAULT_WEIGHTS:

```python
# Database trống hoặc lỗi
weights = WeightLoader.load_weights('DOT-ANY')

# ✅ Vẫn return valid weights:
# {'MIN_WORKING_DAYS': 1.0, 'TEACHER_PREFERENCE': 2.0, ...}

# Solver vẫn chạy bình thường!
```

---

## Tóm Tắt

1. **Seed data**: `seed_rang_buoc_mem()` (1 lần)
2. **Dùng trong code**: Thêm `ma_dot='...'` vào `TimetableState()`
3. **Thay đổi weights**: Qua Admin UI, không cần restart
4. **Failsafe**: Database trống → vẫn hoạt động bình thường

**Xong!** 🎉
