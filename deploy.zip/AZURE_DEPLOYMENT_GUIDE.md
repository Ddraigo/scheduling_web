# Hướng dẫn Deploy Django + SQL Server lên Azure

## 📋 Tổng quan
- **Web App**: Azure App Service (Python 3.11)
- **Database**: Azure SQL Database (tương thích SQL Server)
- **Cost**: $200 credit miễn phí tháng đầu → dùng ~40 tháng
- **Thời gian**: ~30-45 phút

---

## Bước 1: Đăng ký Azure Free Account

### 1.1. Tạo tài khoản
1. Truy cập: https://azure.microsoft.com/free/
2. Click "Start free" → Đăng nhập bằng Microsoft account (hoặc tạo mới)
3. Điền thông tin:
   - Số điện thoại (nhận OTP)
   - **Thẻ tín dụng/debit** (không charge, chỉ để verify)
   - Địa chỉ
4. Hoàn thành → Nhận **$200 credit** (valid 30 ngày)

### 1.2. Xác nhận
```
✅ Student account: Có thể dùng Azure for Students ($100, không cần thẻ)
   → https://azure.microsoft.com/free/students/
```

---

## Bước 2: Cài đặt Azure CLI

### 2.1. Trên Windows (PowerShell Admin)
```powershell
# Download và cài
Invoke-WebRequest -Uri https://aka.ms/installazurecliwindows -OutFile .\AzureCLI.msi
Start-Process msiexec.exe -Wait -ArgumentList '/I AzureCLI.msi /quiet'

# Restart terminal, kiểm tra
az --version
```

### 2.2. Hoặc dùng pip (trong venv)
```bash
pip install azure-cli
az --version
```

### 2.3. Đăng nhập
```bash
az login
# Browser sẽ mở → Đăng nhập với account Azure vừa tạo
# Sau khi đăng nhập thành công, terminal sẽ hiển thị subscription list

# Kiểm tra subscription
az account list --output table
az account set --subscription "Your Subscription Name"
```

---

## Bước 3: Chuẩn bị Project

### 3.1. Cập nhật requirements.txt
```bash
# Thêm vào requirements.txt
gunicorn==21.2.0
whitenoise==6.6.0
psycopg2-binary==2.9.9  # Optional: nếu muốn dùng PostgreSQL sau
```

### 3.2. Tạo file `startup.sh`
```bash
# File: startup.sh
#!/bin/bash
python manage.py collectstatic --noinput
python manage.py migrate
gunicorn config.wsgi:application --bind 0.0.0.0:8000 --workers 3 --timeout 600
```

### 3.3. Cập nhật `settings.py`
```python
# config/settings.py

import os
from pathlib import Path

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = os.environ.get('SECRET_KEY', 'your-default-secret-key-change-this')

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = os.environ.get('DEBUG', 'False') == 'True'

ALLOWED_HOSTS = [
    'localhost',
    '127.0.0.1',
    '.azurewebsites.net',  # Cho phép tất cả subdomain của Azure
]

# Static files (CSS, JavaScript, Images)
STATIC_URL = '/static/'
STATIC_ROOT = BASE_DIR / 'staticfiles'
STATICFILES_STORAGE = 'whitenoise.storage.CompressedManifestStaticFilesStorage'

# Database - Support both local and Azure
if 'RDS_DB_NAME' in os.environ:
    # Azure SQL Database
    DATABASES = {
        'default': {
            'ENGINE': 'mssql',
            'NAME': os.environ.get('RDS_DB_NAME'),
            'USER': os.environ.get('RDS_USERNAME'),
            'PASSWORD': os.environ.get('RDS_PASSWORD'),
            'HOST': os.environ.get('RDS_HOSTNAME'),
            'PORT': os.environ.get('RDS_PORT', '1433'),
            'OPTIONS': {
                'driver': 'ODBC Driver 18 for SQL Server',
                'extra_params': 'Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;',
            },
        }
    }
else:
    # Local development (giữ nguyên config hiện tại)
    DATABASES = {
        'default': {
            'ENGINE': 'mssql',
            'NAME': 'CSDL_TKB',
            'USER': 'sa',
            'PASSWORD': 'sa',
            'HOST': 'localhost',
            'PORT': '1433',
            'OPTIONS': {
                'driver': 'ODBC Driver 18 for SQL Server',
                'extra_params': 'TrustServerCertificate=yes;',
            },
        }
    }

# Middleware - Thêm WhiteNoise
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'whitenoise.middleware.WhiteNoiseMiddleware',  # Thêm dòng này
    # ... các middleware khác giữ nguyên
]

# CSRF trusted origins
CSRF_TRUSTED_ORIGINS = [
    'https://*.azurewebsites.net',
]
```

### 3.4. Tạo `.deployment` file (optional)
```ini
# File: .deployment
[config]
command = bash startup.sh
```

---

## Bước 4: Tạo Azure SQL Database

### 4.1. Tạo SQL Server
```bash
# Set variables
RESOURCE_GROUP="scheduling-rg"
LOCATION="southeastasia"  # Gần Việt Nam nhất
SQL_SERVER="scheduling-sql-$(date +%s)"  # Tên unique
SQL_ADMIN="sqladmin"
SQL_PASSWORD="YourSecurePassword123!"  # ĐỔI MẬT KHẨU NÀY!

# Tạo resource group
az group create --name $RESOURCE_GROUP --location $LOCATION

# Tạo SQL Server
az sql server create \
  --name $SQL_SERVER \
  --resource-group $RESOURCE_GROUP \
  --location $LOCATION \
  --admin-user $SQL_ADMIN \
  --admin-password $SQL_PASSWORD

# Lưu lại tên server
echo "SQL Server name: ${SQL_SERVER}.database.windows.net"
```

### 4.2. Tạo Database
```bash
az sql db create \
  --resource-group $RESOURCE_GROUP \
  --server $SQL_SERVER \
  --name CSDL_TKB \
  --service-objective Basic \
  --backup-storage-redundancy Local

# Check status
az sql db show \
  --resource-group $RESOURCE_GROUP \
  --server $SQL_SERVER \
  --name CSDL_TKB \
  --query '{Name:name, Status:status, Edition:edition}' \
  --output table
```

### 4.3. Cấu hình Firewall
```bash
# Cho phép Azure services truy cập
az sql server firewall-rule create \
  --resource-group $RESOURCE_GROUP \
  --server $SQL_SERVER \
  --name AllowAzureServices \
  --start-ip-address 0.0.0.0 \
  --end-ip-address 0.0.0.0

# Cho phép IP máy local (để restore database)
MY_IP=$(curl -s ifconfig.me)
az sql server firewall-rule create \
  --resource-group $RESOURCE_GROUP \
  --server $SQL_SERVER \
  --name AllowMyIP \
  --start-ip-address $MY_IP \
  --end-ip-address $MY_IP

echo "Your IP: $MY_IP has been whitelisted"
```

---

## Bước 5: Migrate Database lên Azure SQL

### 5.1. Backup database local
```powershell
# Trên SQL Server Management Studio (SSMS)
# Right-click database CSDL_TKB → Tasks → Back Up → Full backup → OK
# File .bak sẽ được lưu tại: C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\Backup\

# Hoặc dùng command
sqlcmd -S localhost -U sa -P sa -Q "BACKUP DATABASE CSDL_TKB TO DISK='C:\Temp\CSDL_TKB.bak' WITH FORMAT"
```

### 5.2. Restore lên Azure SQL (Option 1: Export/Import)
```powershell
# Cài SQL Server Management Studio (SSMS) nếu chưa có
# https://aka.ms/ssmsfullsetup

# Trong SSMS:
# 1. Connect to LOCAL server (localhost)
# 2. Right-click database CSDL_TKB → Tasks → Export Data-tier Application
# 3. Save as .bacpac file → C:\Temp\CSDL_TKB.bacpac

# 4. Connect to AZURE server
#    Server name: scheduling-sql-xxxxxx.database.windows.net
#    Authentication: SQL Server Authentication
#    Login: sqladmin
#    Password: YourSecurePassword123!

# 5. Right-click "Databases" → Import Data-tier Application
# 6. Browse to C:\Temp\CSDL_TKB.bacpac → Next → Next → Finish
```

### 5.3. Restore lên Azure SQL (Option 2: SqlPackage CLI)
```bash
# Download SqlPackage
# https://learn.microsoft.com/en-us/sql/tools/sqlpackage/sqlpackage-download

# Export từ local
SqlPackage /Action:Export \
  /SourceServerName:localhost \
  /SourceDatabaseName:CSDL_TKB \
  /SourceUser:sa \
  /SourcePassword:sa \
  /TargetFile:CSDL_TKB.bacpac

# Import lên Azure
SqlPackage /Action:Import \
  /SourceFile:CSDL_TKB.bacpac \
  /TargetServerName:${SQL_SERVER}.database.windows.net \
  /TargetDatabaseName:CSDL_TKB \
  /TargetUser:$SQL_ADMIN \
  /TargetPassword:$SQL_PASSWORD
```

### 5.4. Verify data
```bash
# Test connection với Azure SQL
sqlcmd -S ${SQL_SERVER}.database.windows.net -d CSDL_TKB -U $SQL_ADMIN -P $SQL_PASSWORD -Q "SELECT COUNT(*) FROM tb_DOT_XEP"
```

---

## Bước 6: Deploy Web App

### 6.1. Tạo App Service Plan
```bash
APP_NAME="scheduling-web-$(date +%s)"  # Tên unique

# Tạo App Service Plan (Free tier)
az appservice plan create \
  --name ${APP_NAME}-plan \
  --resource-group $RESOURCE_GROUP \
  --sku F1 \
  --is-linux

echo "App name will be: ${APP_NAME}.azurewebsites.net"
```

### 6.2. Tạo Web App
```bash
az webapp create \
  --resource-group $RESOURCE_GROUP \
  --plan ${APP_NAME}-plan \
  --name $APP_NAME \
  --runtime "PYTHON:3.11"
```

### 6.3. Cấu hình Environment Variables
```bash
# Database connection
az webapp config appsettings set \
  --resource-group $RESOURCE_GROUP \
  --name $APP_NAME \
  --settings \
    RDS_DB_NAME=CSDL_TKB \
    RDS_USERNAME=$SQL_ADMIN \
    RDS_PASSWORD=$SQL_PASSWORD \
    RDS_HOSTNAME=${SQL_SERVER}.database.windows.net \
    RDS_PORT=1433 \
    SECRET_KEY="$(openssl rand -base64 32)" \
    DEBUG=False \
    WEBSITE_HTTPLOGGING_RETENTION_DAYS=7

# Check settings
az webapp config appsettings list \
  --resource-group $RESOURCE_GROUP \
  --name $APP_NAME \
  --output table
```

### 6.4. Cấu hình startup command
```bash
az webapp config set \
  --resource-group $RESOURCE_GROUP \
  --name $APP_NAME \
  --startup-file "startup.sh"
```

---

## Bước 7: Deploy Code

### 7.1. Deploy từ local (Git)
```bash
cd D:\HOCTAP\DU_AN_CNTT\scheduling_web

# Init git nếu chưa có
git init
git add .
git commit -m "Initial commit for Azure deployment"

# Get deployment credentials
az webapp deployment user set \
  --user-name deployuser \
  --password "DeployPassword123!"

# Get Git URL
GIT_URL=$(az webapp deployment source config-local-git \
  --name $APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --query url \
  --output tsv)

# Add Azure remote và push
git remote add azure $GIT_URL
git push azure master
```

### 7.2. Hoặc deploy từ ZIP
```bash
# Tạo zip file (loại trừ venv, __pycache__)
Compress-Archive -Path .\* -DestinationPath deploy.zip -Force -Exclude venv,__pycache__,.git

# Deploy
az webapp deployment source config-zip \
  --resource-group $RESOURCE_GROUP \
  --name $APP_NAME \
  --src deploy.zip
```

---

## Bước 8: Cài ODBC Driver trên Azure

### 8.1. Thêm startup script
```bash
# Tạo file: startup_with_odbc.sh
cat > startup_with_odbc.sh << 'EOF'
#!/bin/bash

# Install ODBC Driver 18 for SQL Server
curl https://packages.microsoft.com/keys/microsoft.asc | apt-key add -
curl https://packages.microsoft.com/config/ubuntu/20.04/prod.list > /etc/apt/sources.list.d/mssql-release.list
apt-get update
ACCEPT_EULA=Y apt-get install -y msodbcsql18

# Run Django
python manage.py collectstatic --noinput
python manage.py migrate
gunicorn config.wsgi:application --bind 0.0.0.0:8000 --workers 3 --timeout 600
EOF

# Upload và set startup
az webapp config set \
  --resource-group $RESOURCE_GROUP \
  --name $APP_NAME \
  --startup-file "startup_with_odbc.sh"
```

---

## Bước 9: Kiểm tra và Debug

### 9.1. Xem logs
```bash
# Enable logging
az webapp log config \
  --name $APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --application-logging filesystem \
  --detailed-error-messages true \
  --failed-request-tracing true \
  --web-server-logging filesystem

# Stream logs
az webapp log tail \
  --name $APP_NAME \
  --resource-group $RESOURCE_GROUP
```

### 9.2. Test website
```bash
# Open in browser
az webapp browse --name $APP_NAME --resource-group $RESOURCE_GROUP

# Or curl
curl https://${APP_NAME}.azurewebsites.net
```

### 9.3. SSH vào container (debug)
```bash
az webapp ssh --name $APP_NAME --resource-group $RESOURCE_GROUP

# Trong SSH session:
python manage.py shell
>>> from django.db import connection
>>> connection.cursor()
```

---

## Bước 10: Tối ưu hóa (Optional)

### 10.1. Upgrade tier nếu cần
```bash
# Basic tier (tốt hơn Free, ~$13/month)
az appservice plan update \
  --name ${APP_NAME}-plan \
  --resource-group $RESOURCE_GROUP \
  --sku B1
```

### 10.2. Setup Custom Domain
```bash
# Add custom domain
az webapp config hostname add \
  --webapp-name $APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --hostname yourdomain.com

# Enable HTTPS
az webapp config ssl bind \
  --certificate-thumbprint <thumbprint> \
  --ssl-type SNI \
  --name $APP_NAME \
  --resource-group $RESOURCE_GROUP
```

### 10.3. Setup Application Insights (Monitoring)
```bash
az monitor app-insights component create \
  --app ${APP_NAME}-insights \
  --location $LOCATION \
  --resource-group $RESOURCE_GROUP \
  --application-type web

# Link to web app
INSTRUMENTATION_KEY=$(az monitor app-insights component show \
  --app ${APP_NAME}-insights \
  --resource-group $RESOURCE_GROUP \
  --query instrumentationKey \
  --output tsv)

az webapp config appsettings set \
  --name $APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --settings APPINSIGHTS_INSTRUMENTATIONKEY=$INSTRUMENTATION_KEY
```

---

## Bước 11: Quản lý Chi phí

### 11.1. Kiểm tra credit còn lại
```bash
# Login Azure Portal: https://portal.azure.com
# → Subscriptions → Overview → See credit balance
```

### 11.2. Set budget alert
```bash
az consumption budget create \
  --budget-name monthly-budget \
  --amount 50 \
  --time-grain Monthly \
  --start-date 2025-01-01 \
  --end-date 2026-01-01
```

### 11.3. Cost estimate
```
Free tier (Tháng đầu với $200 credit):
├── App Service F1: Free
├── Azure SQL Basic: $4.99/month → $0 (dùng credit)
└── Bandwidth: ~$0.10/month

Sau khi hết credit:
├── App Service F1: Free (giới hạn 60 min CPU/day)
├── Azure SQL Basic: $4.99/month
└── Total: ~$5/month
```

---

## 🚨 Troubleshooting

### Lỗi 1: "ODBC Driver not found"
```bash
# SSH vào container
az webapp ssh --name $APP_NAME --resource-group $RESOURCE_GROUP

# Kiểm tra ODBC drivers
odbcinst -q -d

# Nếu không có driver 18, cài thủ công
curl https://packages.microsoft.com/keys/microsoft.asc | apt-key add -
ACCEPT_EULA=Y apt-get install -y msodbcsql18
```

### Lỗi 2: "Login failed for user"
```bash
# Kiểm tra connection string
az webapp config appsettings list \
  --name $APP_NAME \
  --resource-group $RESOURCE_GROUP \
  | grep RDS

# Test connection từ local
sqlcmd -S ${SQL_SERVER}.database.windows.net -d CSDL_TKB -U $SQL_ADMIN -P $SQL_PASSWORD
```

### Lỗi 3: "Static files not loading"
```bash
# Chạy collectstatic manual
az webapp ssh --name $APP_NAME --resource-group $RESOURCE_GROUP
cd /home/site/wwwroot
python manage.py collectstatic --noinput
```

### Lỗi 4: "Container didn't respond to HTTP pings"
```bash
# Check logs
az webapp log tail --name $APP_NAME --resource-group $RESOURCE_GROUP

# Thường do:
# - startup.sh không executable: chmod +x startup.sh
# - Port binding sai: dùng 0.0.0.0:8000
# - Timeout quá ngắn: tăng --timeout 600
```

---

## 📚 Tài liệu tham khảo

- Azure App Service Python: https://learn.microsoft.com/en-us/azure/app-service/quickstart-python
- Azure SQL Database: https://learn.microsoft.com/en-us/azure/azure-sql/
- Django deployment checklist: https://docs.djangoproject.com/en/5.0/howto/deployment/checklist/
- ODBC Driver 18: https://learn.microsoft.com/en-us/sql/connect/odbc/download-odbc-driver-for-sql-server

---

## 🎯 Checklist Deploy

- [ ] Azure account created with $200 credit
- [ ] Azure CLI installed and logged in
- [ ] requirements.txt updated with gunicorn, whitenoise
- [ ] settings.py updated for Azure (ALLOWED_HOSTS, DATABASES)
- [ ] startup.sh created
- [ ] Azure SQL Server created
- [ ] Database restored to Azure SQL
- [ ] App Service created
- [ ] Environment variables configured
- [ ] Code deployed (git or zip)
- [ ] ODBC Driver installed on container
- [ ] Website accessible at https://{app-name}.azurewebsites.net
- [ ] Admin login works
- [ ] Database queries working

---

**Estimated total time: 30-45 minutes**
**Cost: $0 (first 3-4 months with $200 credit), then ~$5/month**
