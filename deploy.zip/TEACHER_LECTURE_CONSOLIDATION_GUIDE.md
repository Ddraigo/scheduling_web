# 📚 TEACHER LECTURE CONSOLIDATION - CHI TIẾT TỪng BƯỚC

## 🎯 ĐỊNH NGHĨA

**Teacher Lecture Consolidation (S6)** = **GOM CÁC CA HỌC LIÊN TIẾP CỦA GIÁO VIÊN CÙNG PHÒNG**

Mục tiêu: 
- Giáo viên không phải chạy từ phòng này sang phòng khác giữa các tiết dạy liên tiếp
- Giảm mệt mỏi, tiết kiệm thời gian di chuyển

---

## 📍 MỘT VÍ DỤ THỰC TẾ

### **Tình huống 1: LẬU PHẠT (cost = +1)**

```
GV001 dạy 2 khóa học liên tiếp:
┌─────────────────────────────────────┐
│ Thứ 2 (T2)                          │
├─────────────────────────────────────┤
│ Ca 1: LOP-00001 (LT) - Phòng B201   │ ← Giảng viên ở phòng B201
│ Ca 2: LOP-00004 (LT) - Phòng B202   │ ← Giảng viên phải chạy sang B202
└─────────────────────────────────────┘

❌ TÌNH HỌC:
  - 2 tiết liên tiếp cùng loại (LT + LT = cùng type)
  - Nhưng dùng phòng khác (B201 ≠ B202)
  - GV phải chuyển phòng giữa tiết
  → PENALTY = +1

✅ TỐI ƯU:
  - Nên xếp cả 2 vào B201 (hoặc cả 2 vào B202)
```

### **Tình huống 2: KHÔNG PHẠT (cost = 0)**

```
GV003 dạy 2 khóa học liên tiếp nhưng khác TYPE:
┌─────────────────────────────────────┐
│ Thứ 2 (T2)                          │
├─────────────────────────────────────┤
│ Ca 1: LOP-00002 (TH) - Phòng A201   │ ← Thực hành (PC, máy tính)
│ Ca 2: LOP-00032 (LT) - Phòng B201   │ ← Lý thuyết (TV, máy chiếu)
└─────────────────────────────────────┘

✅ KHÔNG PHẠT:
  - 2 tiết liên tiếp nhưng KHÁC type (TH + LT ≠ cùng type)
  - PHẢI đổi phòng vì:
    - TH cần phòng có PC (A201)
    - LT cần phòng có TV (B201)
  - Không thể dùng phòng chung → không phạt
  → PENALTY = 0 (được phép)
```

### **Tình huống 3: KHÔNG LIÊN TIẾP (không kiểm tra)**

```
GV001 dạy 2 tiết nhưng CÓ GAP:
┌─────────────────────────────────────┐
│ Thứ 2 (T2)                          │
├─────────────────────────────────────┤
│ Ca 1: LOP-00001 (LT) - Phòng B201   │
│ Ca 2: [TRỐNG - GV có thể nghỉ/làm việc khác]
│ Ca 3: LOP-00004 (LT) - Phòng B202   │
└─────────────────────────────────────┘

✅ KHÔNG KIỂM TRA:
  - Ca 1 (B201) → [GAP] → Ca 3 (B202)
  - Không liên tiếp (không phải consecutive slots)
  - GV có thời gian di chuyển/chuẩn bị
  → PENALTY = 0 (không phạt)
```

---

## 🔍 CHI TIẾT LOGIC KIỂM TRA

### **Bước 1: Gom tất cả tiết của GV**

```python
# Từ code: _compute_teacher_lecture_consolidation_penalty()

for course_idx, lectures_dict in self.teacher_course_lectures[teacher].items():
    for lecture_id, assignment in lectures_dict.items():
        if assignment is not None:  # Đã được xếp
            period, room_idx = assignment
            day, slot = self.instance.period_to_slot(period)
            all_lectures.append({
                'day': day,
                'slot': slot,
                'period': period,
                'room_idx': room_idx,
                'course_idx': course_idx,
                'course_type': course_type  # ← LT hay TH
            })
```

**Kết quả**: Danh sách TẤT CẢ tiết của GV, bao gồm:
- Ngày (0-5: T2-T7)
- Slot (0-4: Ca 1-5)
- Phòng (room_idx)
- Loại khóa học (course_type: "LT" hoặc "TH")

---

### **Bước 2: Sắp xếp theo thời gian**

```python
# Sort by day, then slot
all_lectures.sort(key=lambda x: (x['day'], x['slot']))
```

**Kết quả**: Danh sách tiết sắp xếp **THEO THỨ TỰ THỜI GIAN**

Ví dụ:
```
[
  {'day': 0, 'slot': 1, 'room_idx': 2, 'course_type': 'LT'},    # T2 Ca2 Phòng B201 LT
  {'day': 0, 'slot': 2, 'room_idx': 3, 'course_type': 'LT'},    # T2 Ca3 Phòng B202 LT ← Liền sau!
  {'day': 1, 'slot': 3, 'room_idx': 2, 'course_type': 'TH'},    # T3 Ca4 Phòng B201 TH ← Có gap
  ...
]
```

---

### **Bước 3: Kiểm tra từng cặp tiết LIÊN TIẾP**

```python
for i in range(len(all_lectures) - 1):
    lec1 = all_lectures[i]
    lec2 = all_lectures[i + 1]
    
    # ⭐ ĐIỀU KIỆN 1: Liên tiếp cùng ngày + slot cạnh nhau
    if lec1['day'] == lec2['day'] and lec2['slot'] == lec1['slot'] + 1:
        
        # ⭐ ĐIỀU KIỆN 2: Phòng khác nhau
        if lec1['room_idx'] != lec2['room_idx']:
            
            # ⭐ ĐIỀU KIỆN 3: CÙNG LOẠI KHÓA HỌC (KEY LOGIC!)
            if lec1['course_type'] and lec2['course_type'] and lec1['course_type'] == lec2['course_type']:
                penalty += 1  # Same type → should use same room
```

**Tất cả 3 điều kiện phải thỏa mãn mới bị phạt:**

| Điều kiện | Kiểm tra | Ý nghĩa |
|-----------|----------|---------|
| 1 | `day1 == day2 AND slot2 == slot1 + 1` | 2 tiết phải liên tiếp cùng ngày |
| 2 | `room1 ≠ room2` | 2 tiết dùng phòng khác |
| 3 | `type1 == type2` | 2 tiết cùng loại (LT hoặc TH) |

---

## 🧮 CÔNG THỨC TÍNH PENALTY

```
penalty = 0

FOR i = 0 TO len(all_lectures)-2:
    lec1 = all_lectures[i]
    lec2 = all_lectures[i+1]
    
    IF (lec1.day == lec2.day) AND (lec2.slot == lec1.slot + 1):
        # Liên tiếp cùng ngày
        
        IF lec1.room ≠ lec2.room:
            # Phòng khác
            
            IF lec1.type == lec2.type:
                # ✅ Cùng loại → PHẠT
                penalty += 1
            ELSE:
                # LT↔TH → Không phạt (bắt buộc đổi)
                penalty += 0
    
RETURN penalty
```

---

## 📊 VÍ DỤ TÍNH TOÁN

### **Ví dụ 1: GV001 dạy 4 tiết trong 1 tuần**

```
Danh sách tiết GV001:
┌──────┬─────┬────────┬──────────┬──────┐
│ Thứ  │ Ca  │ Phòng  │ Loại     │ Là   │
├──────┼─────┼────────┼──────────┼──────┤
│ T2   │ Ca1 │ B201   │ LT       │ Tiết 1
│ T2   │ Ca2 │ B202   │ LT       │ Tiết 2 ← Liền T2-Ca1, khác phòng, cùng LT → PENALTY+1
│ T2   │ Ca3 │ B203   │ LT       │ Tiết 3 ← Liền T2-Ca2, khác phòng, cùng LT → PENALTY+1
│ T3   │ Ca1 │ A201   │ TH       │ Tiết 4 ← Không liền (T2 → T3 có gap) → No penalty
└──────┴─────┴────────┴──────────┴──────┘

Tính toán:
- Tiết 1 vs Tiết 2: (day: 0==0) + (slot: 1==0+1) + (room: B201≠B202) + (type: LT==LT) ✓✓✓
  → PENALTY += 1
- Tiết 2 vs Tiết 3: (day: 0==0) + (slot: 2==1+1) + (room: B202≠B203) + (type: LT==LT) ✓✓✓
  → PENALTY += 1
- Tiết 3 vs Tiết 4: (day: 0≠1) → Không liền, không kiểm tra
  → PENALTY += 0

TOTAL PENALTY = 2
```

---

### **Ví dụ 2: GV003 dạy 3 tiết (LT + TH + LT)**

```
Danh sách tiết GV003:
┌──────┬─────┬────────┬──────────┐
│ Thứ  │ Ca  │ Phòng  │ Loại     │
├──────┼─────┼────────┼──────────┤
│ T2   │ Ca1 │ A201   │ TH       │ Tiết 1
│ T2   │ Ca2 │ B201   │ LT       │ Tiết 2 ← Liền, khác phòng, KHÁC TYPE (TH≠LT)
│ T2   │ Ca3 │ B202   │ LT       │ Tiết 3 ← Liền, khác phòng, cùng TYPE (LT==LT)
└──────┴─────┴────────┴──────────┘

Tính toán:
- Tiết 1 vs Tiết 2: (day: 0==0) + (slot: 1==0+1) + (room: A201≠B201) + (type: TH≠LT) ✗
  → Khác type (LT↔TH là bắt buộc đổi phòng)
  → PENALTY += 0
- Tiết 2 vs Tiết 3: (day: 0==0) + (slot: 2==1+1) + (room: B201≠B202) + (type: LT==LT) ✓✓✓
  → PENALTY += 1

TOTAL PENALTY = 1
```

---

## ⚠️ ĐIỂM LƯU Ý QUAN TRỌNG

### **1️⃣ CHỈ KIỂM TRA CONSECUTIVE (Liền kề)**

```
❌ SAI: Tiết 1 Ca1 (B201) → [Tiết 2 Ca3 (B202)] 
   Không liền kề (Ca1 → Ca3 có gap) → Không kiểm tra

✅ ĐÚNG: Tiết 1 Ca1 (B201) → Tiết 2 Ca2 (B202)
   Liền kề (Ca1 → Ca2) → Kiểm tra penalty
```

---

### **2️⃣ CHỈ PHẠT KHI CÙNG TYPE**

```
❌ LT → TH (khác phòng):
   A. LT cần phòng có TV/máy chiếu
   B. TH cần phòng có PC/máy tính
   → PHẢI đổi phòng → KHÔNG PHẠT ✓

✅ LT → LT (khác phòng):
   Cả 2 đều LT, nên CÓ THỂ dùng cùng phòng
   → Không cần đổi → PHẠT ❌
```

---

### **3️⃣ WEIGHT = 1.8 (ƯU TIÊN CAO)**

```
Trong công thức tính cost:
  total_cost = ... + teacher_lecture_consolidation * 1.8 + ...

So sánh các weight:
  WEIGHT_TEACHER_PREFERENCE = 2.0  ← Cao nhất (GV mong muốn)
  WEIGHT_TEACHER_LECTURE_CONSOLIDATION = 1.8  ← Cao thứ 2
  WEIGHT_LECTURE_CONSECUTIVENESS = 1.5
  WEIGHT_CURRICULUM_COMPACTNESS = 2.0 (nếu áp dụng)
  ...

→ Teacher consolidation là ưu tiên CAO, được thuật toán coi trọng
```

---

## 🔄 CÁC BƯỚC THUẬT TOÁN XỬ LÝ

### **Khi khởi tạo giải pháp (Initial Solution):**
```
1. Gán tiết cho giáo viên
2. Tính penalty consolidation dựa trên vị trí + phòng
3. Nếu consolidation penalty cao → Thuật toán sẽ optimize (điều chỉnh xếp)
4. Lần lượt cải thiện lịch cho đến khi tối ưu
```

### **Khi tối ưu hóa (Optimization):**
```
1. Thử di chuyển một tiết tới phòng/slot khác
2. Tính delta cost (bao gồm consolidation penalty)
3. Nếu delta < 0 (tốt hơn) → Chấp nhận
4. Nếu delta >= 0 (tệ hơn) → Có thể từ chối hoặc dùng simulated annealing
```

---

## 📈 IMPACT TRÊN LỜI GIẢI

### **Tốt hơn**
```
GV dạy cùng loại (LT hoặc TH) trong cùng phòng liên tiếp
→ Không phải chuyển phòng
→ Penalty = 0
→ Cost giảm, lịch tối ưu hơn ✓
```

### **Tệ hơn**
```
GV dạy cùng loại (LT hoặc TH) nhưng phòng khác liên tiếp
→ Phải chuyển phòng
→ Penalty = +1 per transition
→ Cost tăng, lịch kém hơn ✗
```

### **Trung tính**
```
GV dạy khác loại (LT↔TH) liên tiếp + phòng khác
→ Bắt buộc phải đổi phòng (không có lựa chọn)
→ Penalty = 0 (được phép)
→ Không ảnh hưởng cost ✓
```

---

## 💡 TÓMING TẮT

| Yếu tố | Chi tiết |
|--------|----------|
| **Tên** | Teacher Lecture Consolidation (S6) |
| **Mục đích** | GV dạy liên tiếp cùng phòng (không phải chuyển phòng) |
| **Kiểu** | Soft constraint (có thể vi phạm, nhưng tốn cost) |
| **Weight** | 1.8 (ưu tiên cao) |
| **Công thức** | Đếm lần GV đổi phòng giữa tiết liên tiếp cùng TYPE |
| **Điều kiện** | (1) Liên tiếp cùng ngày + (2) Phòng khác + (3) Cùng type |
| **Không phạt** | Tiết khác type (LT↔TH) hay tiết không liền |

---

