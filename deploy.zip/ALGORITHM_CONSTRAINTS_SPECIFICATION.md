# Đặc Tả Chi Tiết Các Ràng Buộc Thuật Toán Xếp Thời Khóa Biểu

> **Cập nhật lần cuối:** Tuần 7 - Dự án Xếp Thời Khóa Biểu Tự Động  
> **Thuật toán:** CB-CTT (Curriculum-Based Course Timetabling) - ITC-2007 Track 3  
> **File nguồn:** `apps/scheduling/algorithms/algorithms_core.py`

---

## Mục Lục

1. [Tổng Quan Thuật Toán](#1-tổng-quan-thuật-toán)
2. [Ràng Buộc Cứng (Hard Constraints)](#2-ràng-buộc-cứng-hard-constraints)
3. [Ràng Buộc Mềm (Soft Constraints)](#3-ràng-buộc-mềm-soft-constraints)
4. [Trọng Số và Công Thức Tính Điểm](#4-trọng-số-và-công-thức-tính-điểm)
5. [Cơ Chế Metaheuristics](#5-cơ-chế-metaheuristics)
6. [Quy Tắc Xếp Lịch Đặc Thù Việt Nam](#6-quy-tắc-xếp-lịch-đặc-thù-việt-nam)

---

## 1. Tổng Quan Thuật Toán

### 1.1. Bài Toán CB-CTT
Bài toán **Curriculum-Based Course Timetabling (CB-CTT)** là bài toán xếp lịch học dựa trên chương trình đào tạo, trong đó:
- **Đầu vào:** Danh sách khóa học, phòng học, giảng viên, chương trình đào tạo (curriculum)
- **Đầu ra:** Thời khóa biểu phân công mỗi buổi học (lecture) vào một cặp (tiết, phòng)

### 1.2. Cấu Trúc Dữ Liệu Chính

```python
@dataclass
class Room:
    id: str          # Mã phòng
    capacity: int    # Sức chứa
    equipment: str   # Thiết bị có sẵn
    room_type: str   # "LT" (Lý thuyết) hoặc "TH" (Thực hành)

@dataclass
class Course:
    id: str              # Mã môn học
    teacher: str         # Mã giảng viên
    lectures: int        # Số buổi/tuần
    min_working_days: int # Số ngày dạy tối thiểu
    students: int        # Số sinh viên
    course_type: str     # "LT" hoặc "TH"
    equipment: str       # Thiết bị yêu cầu

@dataclass
class Curriculum:
    name: str            # Tên chương trình đào tạo
    courses: List[int]   # Danh sách môn học thuộc chương trình
```

### 1.3. Quy Trình Giải

```
[1] Parse Instance (.ctt file)
         ↓
[2] Build Initial Solution (Backtracking + Random Repair)
         ↓
[3] Metaheuristic Search (Tabu Search hoặc Simulated Annealing)
         ↓
[4] Export Solution (.sol file)
```

---

## 2. Ràng Buộc Cứng (Hard Constraints)

> **Quy tắc:** Tất cả các ràng buộc cứng **PHẢI được thỏa mãn** để lời giải được coi là hợp lệ (feasible).

### H1. Unavailability (Không khả dụng)
```
📋 Mô tả: Một số cặp (khóa học, tiết) bị cấm không được xếp lịch.
```

**Cơ chế kiểm tra:**
```python
def _can_place(self, lecture_id, period, room_idx):
    course_idx = self.instance.lectures[lecture_id].course
    
    # H1: Period availability
    if period in self.instance.unavailability[course_idx]:
        return False  # ❌ Vi phạm
```

**Ví dụ:** Môn C101 không được xếp vào thứ 2, tiết 1 (unavailability: `C101 0 0`)

---

### H2. Room Conflict (Xung đột phòng)
```
📋 Mô tả: Một phòng học chỉ được sử dụng bởi TỐI ĐA 1 buổi học trong mỗi tiết.
```

**Cơ chế kiểm tra:**
```python
def _can_place(self, lecture_id, period, room_idx):
    # H2: Room not already booked at this period
    if room_idx in self.period_rooms[period]:
        return False  # ❌ Vi phạm - phòng đã có người dùng
```

**Tracking state:**
```python
self.period_rooms[period] = {room_idx: lecture_id}  # Dict[int, int]
```

---

### H3. Teacher Conflict (Xung đột giảng viên)
```
📋 Mô tả: Một giảng viên chỉ được dạy TỐI ĐA 1 buổi học trong mỗi tiết.
```

**Cơ chế kiểm tra:**
```python
def _can_place(self, lecture_id, period, room_idx):
    teacher = self.instance.course_teachers[course_idx]
    
    # H3: Teacher conflict
    owner = self.period_teacher_owner[period].get(teacher)
    if owner is not None and owner != lecture_id:
        return False  # ❌ Vi phạm - GV đã dạy tiết khác
```

**Tracking state:**
```python
self.period_teacher_owner[period] = {teacher_id: lecture_id}  # Dict[str, int]
```

---

### H4. Curriculum Conflict (Xung đột chương trình đào tạo)
```
📋 Mô tả: Sinh viên cùng chương trình đào tạo không thể học 2 môn cùng lúc.
          → Các môn thuộc cùng curriculum KHÔNG được xếp vào cùng tiết.
```

**Cơ chế kiểm tra:**
```python
def _can_place(self, lecture_id, period, room_idx):
    # H4: Curriculum conflict
    for curriculum_idx in self.instance.course_curriculums[course_idx]:
        owner = self.period_curriculum_owner[period].get(curriculum_idx)
        if owner is not None and owner != lecture_id:
            return False  # ❌ Vi phạm - cùng curriculum đã có môn khác
```

**Tracking state:**
```python
self.period_curriculum_owner[period] = {curriculum_idx: lecture_id}
```

---

### H5. Capacity Constraint (Sức chứa phòng)
```
📋 Mô tả: Phòng học PHẢI có sức chứa ≥ số sinh viên của môn học.
```

**Cơ chế kiểm tra:**
```python
def _can_place(self, lecture_id, period, room_idx):
    room = self.instance.rooms[room_idx]
    
    # H5: Capacity must be adequate
    if room.capacity < course.students:
        return False  # ❌ Vi phạm - phòng quá nhỏ
```

**Lưu ý:** Đây là **HARD constraint** trong hệ thống này (khác ITC-2007 gốc coi là soft).

---

### H6. Room Type Match (Loại phòng phù hợp)
```
📋 Mô tả: Môn LÝ THUYẾT phải xếp vào phòng LT, môn THỰC HÀNH phải xếp vào phòng TH.
```

**Cơ chế kiểm tra:**
```python
def _can_place(self, lecture_id, period, room_idx):
    # H6: Room type must match
    # LT (Lý thuyết) courses → LT rooms, TH (Thực hành) courses → TH rooms
    if course.course_type != room.room_type:
        return False  # ❌ Vi phạm - loại phòng không khớp
```

---

### H7. Equipment Constraint (Thiết bị yêu cầu)
```
📋 Mô tả: Nếu môn học yêu cầu thiết bị, phòng PHẢI có thiết bị đó.
```

**Cơ chế kiểm tra:**
```python
def _can_place(self, lecture_id, period, room_idx):
    # H7: Equipment - Hard constraint
    if course.equipment:
        room_equipment = room.equipment or ""
        required_equipment = set(eq.strip() for eq in course.equipment.split(','))
        room_equipment_set = set(eq.strip() for eq in room_equipment.split(','))
        
        if not required_equipment.issubset(room_equipment_set):
            return False  # ❌ Vi phạm - thiếu thiết bị
```

---

## 3. Ràng Buộc Mềm (Soft Constraints)

> **Quy tắc:** Các ràng buộc mềm được phép vi phạm nhưng sẽ phát sinh **chi phí (cost)**.  
> Mục tiêu: **Tối thiểu hóa tổng chi phí soft constraints.**

### S1. Room Capacity Overflow (Tràn sức chứa) ⚠️ Đã chuyển sang H5
```
📋 Mô tả: Phạt khi số sinh viên > sức chứa phòng.
          HIỆN TẠI: Đã được implement như HARD constraint (H5).
```

**Công thức (nếu là soft):**
```
penalty = max(0, students - capacity)
```

**Trọng số:** `WEIGHT_ROOM_CAPACITY = 1.0`

---

### S2. Minimum Working Days (Số ngày dạy tối thiểu)
```
📋 Mô tả: Mỗi môn học nên được xếp trên ÍT NHẤT min_working_days ngày khác nhau.
          Nếu không đạt → phạt.
```

**Cơ chế tính penalty:**
```python
def _compute_course_mwd_penalty(self, course_idx: int) -> int:
    """
    Penalty = max(0, min_working_days - actual_active_days)
    
    Ví dụ: Môn yêu cầu 3 ngày, nhưng chỉ xếp được 2 ngày
    → Penalty = 3 - 2 = 1
    """
    course = self.instance.courses[course_idx]
    required_days = course.min_working_days
    actual_days = self.course_active_days[course_idx]  # Số ngày thực tế có lecture
    return max(0, required_days - actual_days)
```

**Tracking state:**
```python
self.course_day_counts[course_idx] = [0] * days  # Số lecture mỗi ngày
self.course_active_days[course_idx] = 0          # Số ngày có lecture
```

**Trọng số:** `WEIGHT_MIN_WORKING_DAYS = 1.0`

---

### S3. Curriculum Compactness (Độ nén chương trình) 🚫 **ĐÃ LOẠI BỎ**
```
📋 Mô tả: Sinh viên cùng curriculum nên có các buổi học LIÊN TIẾP trong ngày,
          không bị các tiết trống xen giữa.

⚠️ TRẠNG THÁI: ĐÃ BỊ VÔ HIỆU HÓA
   Lý do: Xung đột với S7 (Teacher Working Days)
   - S3 muốn lectures phân tán nhiều ngày trong curriculum
   - S7 muốn giảm số ngày làm việc của GV (gom lectures vào ít ngày)
   → Giữ S7, loại S3.
```

**Code (đã comment):**
```python
# self.soft_curriculum_compactness += penalty_delta  # REMOVED: S3 conflicts with S7
```

**Trọng số:** `WEIGHT_CURRICULUM_COMPACTNESS = 0.0` (vô hiệu)

---

### S4. Lecture Consecutiveness (Tiết học liên tiếp)
```
📋 Mô tả: Các buổi học của CÙNG MÔN nên được xếp LIÊN TIẾP trong ngày.
          Ưu tiên patterns: 2 tiết liên tiếp, 3 tiết liên tiếp, 2+2 tiết.
```

**Cơ chế tính penalty:**
```python
def _compute_course_consecutiveness_penalty(self, course_idx: int) -> int:
    """
    Đếm số "gaps" giữa các lectures của cùng môn.
    Gap = khoảng cách > 1 tiết giữa 2 lectures liên tiếp cùng ngày.
    
    Penalty = tổng số gaps (thiếu tính liên tiếp)
    """
    periods = sorted(self.course_assigned_periods[course_idx])
    if len(periods) <= 1:
        return 0
    
    penalty = 0
    for i in range(len(periods) - 1):
        # Kiểm tra xem 2 periods liên tiếp có cùng ngày không
        day1, slot1 = self.instance.period_to_slot(periods[i])
        day2, slot2 = self.instance.period_to_slot(periods[i + 1])
        
        if day1 == day2:
            gap = slot2 - slot1 - 1
            if gap > 0:
                penalty += gap  # Phạt cho mỗi tiết trống xen giữa
    
    return penalty
```

**Ví dụ:**
```
Môn A có 3 lectures:
- Thứ 2: Tiết 1, Tiết 3  → Gap = 1 (tiết 2 bị bỏ qua)
- Thứ 4: Tiết 2

Penalty = 1 (cho gap giữa tiết 1 và tiết 3)
```

**Trọng số:** `WEIGHT_LECTURE_CONSECUTIVENESS = 1.5`

---

### S5. Room Stability (Ổn định phòng)
```
📋 Mô tả: Tất cả lectures của CÙNG MÔN nên được xếp vào CÙNG PHÒNG.
          Mỗi phòng bổ sung sử dụng sẽ bị phạt.
```

**Cơ chế tính penalty:**
```python
def _compute_course_room_penalty(self, course_idx: int) -> int:
    """
    Penalty = số_phòng_sử_dụng - 1 (nếu > 1)
    
    Ví dụ: Môn A dùng 3 phòng khác nhau → Penalty = 3 - 1 = 2
    """
    room_counts = self.course_room_counts[course_idx]
    num_rooms_used = len(room_counts)  # Số phòng khác nhau
    
    if num_rooms_used <= 1:
        return 0
    return num_rooms_used - 1
```

**Tracking state:**
```python
self.course_room_counts[course_idx] = {room_idx: count}  # Counter
```

**Trọng số:** `WEIGHT_ROOM_STABILITY = 1.0`

---

### S6. Teacher Lecture Consolidation (Gom tiết dạy GV)
```
📋 Mô tả: Giảng viên dạy LIÊN TIẾP các buổi nên ở CÙNG PHÒNG.
          Nếu đổi phòng giữa 2 tiết liên tiếp → phạt.
          
          Mục đích: Giảm di chuyển của GV giữa các phòng.
```

**Cơ chế tính penalty:**
```python
def _compute_teacher_lecture_consolidation_penalty(self, teacher: str) -> int:
    """
    Penalty = số lần GV đổi phòng giữa 2 tiết LIÊN TIẾP cùng ngày.
    
    Với mỗi GV:
    1. Lấy tất cả lectures được assign, nhóm theo ngày
    2. Trong mỗi ngày, sort lectures theo slot
    3. Đếm số lần room thay đổi giữa slots liên tiếp
    """
    penalty = 0
    
    # Nhóm lectures theo ngày
    lectures_by_day = defaultdict(list)
    for course_idx, lectures_dict in self.teacher_course_lectures[teacher].items():
        for lecture_id, assignment in lectures_dict.items():
            if assignment is None:
                continue
            period, room_idx = assignment
            day, slot = self.instance.period_to_slot(period)
            lectures_by_day[day].append((slot, room_idx, lecture_id))
    
    # Trong mỗi ngày, kiểm tra room changes
    for day, day_lectures in lectures_by_day.items():
        sorted_lectures = sorted(day_lectures, key=lambda x: x[0])  # Sort by slot
        
        for i in range(1, len(sorted_lectures)):
            prev_slot, prev_room, _ = sorted_lectures[i-1]
            curr_slot, curr_room, _ = sorted_lectures[i]
            
            # Chỉ phạt nếu 2 tiết LIÊN TIẾP (slot chênh lệch = 1)
            if curr_slot - prev_slot == 1 and prev_room != curr_room:
                penalty += 1  # Đổi phòng giữa tiết liên tiếp
    
    return penalty
```

**Ví dụ:**
```
GV A dạy ngày Thứ 2:
- Tiết 1: Phòng R101
- Tiết 2: Phòng R102  → Đổi phòng! Penalty +1
- Tiết 3: Phòng R102  → Không đổi, không phạt
- Tiết 5: Phòng R101  → Không liên tiếp với tiết 3, không xét

Tổng Penalty = 1
```

**Trọng số:** `WEIGHT_TEACHER_LECTURE_CONSOLIDATION = 1.8`

---

### S7. Teacher Working Days (Số ngày làm việc GV)
```
📋 Mô tả: Giảm thiểu số ngày GV phải đến trường dạy.
          GV nên được xếp lịch dạy tập trung vào ÍT NGÀY nhất có thể.
          
          ⭐ ĐÂY LÀ CONSTRAINT CÓ TRỌNG SỐ CAO NHẤT (2.5)
```

**Cơ chế tính penalty:**
```python
def _compute_teacher_working_days_penalty(self, teacher: str) -> int:
    """
    Penalty = actual_working_days - min_feasible_days
    
    Trong đó:
    - actual_working_days: Số ngày thực tế GV có tiết dạy
    - min_feasible_days: Số ngày TỐI THIỂU cần thiết (dựa trên preferences và total lectures)
    
    Thuật toán tính min_feasible_days:
    1. Nếu GV có preferences: Tính số ngày tối thiểu từ preferred periods
    2. Nếu không có preferences: Ước lượng từ tổng số lectures / max_slots_per_day
    """
    # Đếm số ngày thực tế có dạy
    working_days = set()
    total_lectures = 0
    
    for course_idx, lectures_dict in self.teacher_course_lectures[teacher].items():
        for lecture_id, assignment in lectures_dict.items():
            if assignment is None:
                continue
            period, _ = assignment
            day, _ = self.instance.period_to_slot(period)
            working_days.add(day)
            total_lectures += 1
    
    actual_days = len(working_days)
    
    # Tính min_feasible_days dựa trên preferences
    preferred_periods = self.instance.teacher_preferred_periods.get(teacher, set())
    
    if preferred_periods:
        # Đếm số ngày có preferred periods
        preferred_days = set()
        for period in preferred_periods:
            day, _ = self.instance.period_to_slot(period)
            preferred_days.add(day)
        min_feasible_days = min(len(preferred_days), max(1, total_lectures // 4))
    else:
        # Ước lượng: giả sử mỗi ngày tối đa 4-6 tiết
        min_feasible_days = max(1, (total_lectures + 3) // 4)
    
    return max(0, actual_days - min_feasible_days)
```

**Ví dụ:**
```
GV B có 8 lectures, preferences cho thứ 2, 4, 6.
- min_feasible_days = 3 (3 ngày preferred)
- Thực tế xếp được: thứ 2, 3, 4, 5 (4 ngày)
- Penalty = 4 - 3 = 1
```

**Trọng số:** `WEIGHT_TEACHER_WORKING_DAYS = 2.5` ⭐ **CAO NHẤT**

---

### S8. Teacher Preferences (Nguyện vọng GV)
```
📋 Mô tả: Giảng viên có thể khai báo các tiết/ngày MONG MUỐN dạy.
          Xếp lịch NGOÀI nguyện vọng → phạt.
          
          ⭐ ĐÂY LÀ SOFT CONSTRAINT, KHÔNG PHẢI HARD!
```

**Cơ chế tính penalty:**
```python
def _compute_teacher_preference_cost(self, lecture_id: int) -> int:
    """
    Penalty = 1 nếu lecture được xếp NGOÀI preferred periods của GV.
            = 0 nếu lecture NẰM TRONG preferred periods hoặc GV không có preferences.
    """
    assignment = self.assignments.get(lecture_id)
    if assignment is None:
        return 0
    
    period, _ = assignment
    course_idx = self.instance.lectures[lecture_id].course
    teacher = self.instance.course_teachers[course_idx]
    
    preferred_periods = self.instance.teacher_preferred_periods.get(teacher, set())
    
    if not preferred_periods:
        return 0  # GV không có preferences → không phạt
    
    if period not in preferred_periods:
        return 1  # Vi phạm preferences
    
    return 0
```

**Relaxation Logic:**
```
🔄 TỰ ĐỘNG RELAXATION:
- Khi GV có 5 lectures nhưng chỉ 3 slots preferred
- Backtracking sẽ tự động xếp 2 lectures vào non-preferred slots
- 2 violations này được tích lũy vào soft cost
- KHÔNG CẦN can thiệp thủ công
```

**Trọng số:** `WEIGHT_TEACHER_PREFERENCE = 2.0`

---

## 4. Trọng Số và Công Thức Tính Điểm

### 4.1. Bảng Trọng Số

| Constraint | Mã | Weight | Mức Độ Ưu Tiên |
|------------|-----|--------|----------------|
| Teacher Working Days | S7 | 2.5 | 🔴 **Cao nhất** |
| Teacher Preferences | S8 | 2.0 | 🟠 Cao |
| Teacher Lecture Consolidation | S6 | 1.8 | 🟡 Trung bình cao |
| Lecture Consecutiveness | S4 | 1.5 | 🟡 Trung bình |
| Room Stability | S5 | 1.0 | 🟢 Thấp |
| Room Capacity | S1 | 1.0 | 🟢 Thấp |
| Min Working Days | S2 | 1.0 | 🟢 Thấp |
| Curriculum Compactness | S3 | 0.0 | ⚫ **Vô hiệu** |

### 4.2. Công Thức Tổng Chi Phí

```python
total_cost = (
    soft_room_capacity * WEIGHT_ROOM_CAPACITY +                    # S1 × 1.0
    soft_min_working_days * WEIGHT_MIN_WORKING_DAYS +              # S2 × 1.0
    # soft_curriculum_compactness * WEIGHT_CURRICULUM_COMPACTNESS + # S3 × 0.0 (disabled)
    soft_lecture_consecutiveness * WEIGHT_LECTURE_CONSECUTIVENESS + # S4 × 1.5
    soft_room_stability * WEIGHT_ROOM_STABILITY +                  # S5 × 1.0
    soft_teacher_lecture_consolidation * WEIGHT_TEACHER_LECTURE_CONSOLIDATION + # S6 × 1.8
    soft_teacher_working_days * WEIGHT_TEACHER_WORKING_DAYS +      # S7 × 2.5
    soft_teacher_preference_violations * WEIGHT_TEACHER_PREFERENCE  # S8 × 2.0
)
```

### 4.3. Score Breakdown Structure

```python
@dataclass
class ScoreBreakdown:
    room_capacity: int = 0
    min_working_days: int = 0
    curriculum_compactness: int = 0  # Always 0 (disabled)
    lecture_consecutiveness: int = 0
    room_stability: int = 0
    teacher_lecture_consolidation: int = 0
    teacher_working_days: int = 0
    teacher_preference_violations: int = 0
    
    @property
    def total(self) -> int:
        return (self.room_capacity + self.min_working_days + 
                self.curriculum_compactness + self.lecture_consecutiveness + 
                self.room_stability + 
                self.teacher_lecture_consolidation + 
                self.teacher_working_days + 
                self.teacher_preference_violations)
```

---

## 5. Cơ Chế Metaheuristics

### 5.1. Các Phép Toán Cơ Bản (Moves)

#### Move Lecture
```
Di chuyển 1 lecture từ (period₁, room₁) → (period₂, room₂)
```

#### Swap Lectures
```
Hoán đổi vị trí 2 lectures:
- lecture_a: (p₁, r₁) → (p₂, r₂)
- lecture_b: (p₂, r₂) → (p₁, r₁)
```

#### Kempe Chain
```
Di chuyển nhiều lectures đồng thời theo chuỗi xung đột:
1. Chọn lecture gốc, tìm target period
2. Xây dựng chuỗi tất cả lectures có conflict
3. Swap period cho toàn bộ chuỗi
```

### 5.2. Neighborhoods (Lân cận)

| Neighborhood | Mục đích | Chiến lược |
|--------------|----------|------------|
| MoveLecture | Tổng quát | Di chuyển random lecture |
| RoomChange | Room Stability (S5) | Đổi phòng giữ nguyên period |
| PeriodChange | Tổng quát | Đổi period giữ nguyên phòng |
| SwapLectures | Tổng quát | Hoán đổi 2 lectures |
| KempeChain | Tổng quát | Di chuyển chuỗi lectures |
| CapacityFix | Room Capacity (S1) | Tìm phòng lớn hơn |
| ConsecutiveGapFilling | Consecutiveness (S4) | Lấp gaps liên tiếp |
| SwapForPairing | Consecutiveness (S4) | Tạo cặp tiết liên tiếp |
| TeacherPreference | Preferences (S8) | Di chuyển vào preferred |
| TeacherWorkingDays | Working Days (S7) | Gom lectures vào ít ngày |

### 5.3. Tabu Search (TS)

```
THUẬT TOÁN:
1. Start với initial solution
2. Repeat until timeout:
   a. Generate candidate moves từ các neighborhoods
   b. Evaluate delta cost cho mỗi move
   c. Chọn best move không thuộc tabu list (hoặc thỏa aspiration criterion)
   d. Apply move, cập nhật tabu list
   e. Cập nhật best solution nếu cải thiện
3. Return best solution found
```

**Tham số:**
- `tabu_tenure`: Số iterations một move bị cấm (default: 7-15)
- `aspiration_criterion`: Cho phép tabu move nếu cải thiện global best

### 5.4. Simulated Annealing (SA)

```
THUẬT TOÁN:
1. Start với initial solution, nhiệt độ T = T_initial
2. Repeat until timeout:
   a. Generate random neighbor move
   b. delta = cost(neighbor) - cost(current)
   c. If delta < 0: Accept (cải thiện)
   d. Else: Accept với xác suất exp(-delta / T)
   e. Giảm nhiệt độ: T = T * cooling_rate
   f. Cập nhật best solution nếu cải thiện
3. Return best solution found
```

**Tham số:**
- `T_initial`: Nhiệt độ ban đầu (ảnh hưởng acceptance rate)
- `cooling_rate`: Tốc độ nguội (0.95 - 0.999)
- `reheat_threshold`: Ngưỡng reheat khi bị stuck

---

## 6. Quy Tắc Xếp Lịch Đặc Thù Việt Nam

### 6.1. Patterns Tiết Học Theo Số Tín Chỉ

| Số TC | Số tiết/tuần | Pattern ưu tiên |
|-------|--------------|-----------------|
| 2 | 2 | 2 tiết liên tiếp cùng ngày |
| 3 | 3 | 3 tiết liên tiếp HOẶC 2+1 |
| 4 | 4 | 2+2 (2 ngày × 2 tiết liên tiếp) |

### 6.2. Ràng Buộc Loại Phòng (Việt Nam)

```
🏫 Phòng Lý Thuyết (LT):
- Dành cho môn học lý thuyết
- Bàn ghế thường, bảng/projector

💻 Phòng Thực Hành (TH):
- Dành cho môn thực hành (máy tính, thí nghiệm)
- Máy tính, thiết bị chuyên dụng
```

### 6.3. Cấu Trúc Ngày/Tiết Điển Hình

```
Days: 6 (Thứ 2 - Thứ 7)
Periods_per_day: 6 (hoặc 10 cho buổi sáng+chiều)

Buổi sáng: Tiết 1-5
Buổi chiều: Tiết 6-10

Total periods: 6 × 6 = 36 (hoặc 6 × 10 = 60)
```

---

## Phụ Lục: Tóm Tắt Công Thức

### Hard Constraints (PHẢI thỏa mãn)

| Mã | Ràng buộc | Điều kiện |
|----|-----------|-----------|
| H1 | Unavailability | `period ∉ unavailability[course]` |
| H2 | Room Conflict | `room not in period_rooms[period]` |
| H3 | Teacher Conflict | `teacher not in period_teachers[period]` |
| H4 | Curriculum Conflict | `∀c ∈ curriculums: c not in period_curriculum_owner[period]` |
| H5 | Capacity | `room.capacity ≥ course.students` |
| H6 | Room Type | `room.room_type == course.course_type` |
| H7 | Equipment | `course.equipment ⊆ room.equipment` |

### Soft Constraints (Tối thiểu hóa)

| Mã | Ràng buộc | Công thức Penalty |
|----|-----------|-------------------|
| S1 | Room Capacity | `max(0, students - capacity)` |
| S2 | Min Working Days | `max(0, required_days - actual_days)` |
| S3 | Curriculum Compactness | **DISABLED** |
| S4 | Lecture Consecutiveness | `gaps trong cùng ngày` |
| S5 | Room Stability | `rooms_used - 1` |
| S6 | Teacher Consolidation | `room_changes giữa tiết liên tiếp` |
| S7 | Teacher Working Days | `actual_days - min_feasible_days` |
| S8 | Teacher Preferences | `1 nếu ngoài preferred, 0 nếu trong` |

---

> **Ghi chú:** Tài liệu này mô tả trạng thái thuật toán tại thời điểm Tuần 7.  
> Có thể được cập nhật khi có thay đổi về trọng số hoặc logic constraints.
