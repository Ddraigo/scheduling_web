# S7 (Teacher Working Days) Improvement Summary

## Vấn đề ban đầu
- **S7 penalty = 78** sau 400s runtime (không cải thiện từ 80-83)
- TeacherWorkingDaysNeighborhood không hoạt động hiệu quả

## Root Causes Identified

### 1. **BUG NGHIÊM TRỌNG: `_find_free_slots()` logic sai**
```python
# BEFORE (SAI):
def _find_free_slots(self, state, instance, day: int) -> list:
    for slot in range(instance.periods_per_day):
        period = day * instance.periods_per_day + slot
        if period not in state.assignments:  # ❌ SAI! assignments là dict với key=lecture_id
            free_slots.append(slot)

# AFTER (ĐÚNG):
def _find_free_slots(self, state, instance, day: int) -> list:
    for slot in range(instance.periods_per_day):
        period = day * instance.periods_per_day + slot
        occupied_rooms = len(state.period_rooms[period])  # ✓ Đúng cấu trúc
        if occupied_rooms < total_rooms:
            free_slots.append(slot)
```

**Impact**: Hàm luôn trả về empty list → MOVE strategy KHÔNG BAO GIỜ hoạt động!

### 2. **Threshold quá chặt: delta ≤ 5.0**
- Debug output: `move_failed=7461, swap_failed=858` sau 500 calls
- Nhiều moves có delta > 5.0 do S6/S8 tăng khi consolidate lectures
- **Solution**: Tăng threshold lên **15.0** để chấp nhận tradeoff hợp lý

### 3. **SWAP strategy chỉ trong cùng teacher**
- BEFORE: Swap với BẤT KỲ lecture nào trên dense days
- AFTER: Ưu tiên swap TRONG CÙNG TEACHER trước (giảm side effects)
- Fallback: Swap với other teachers nếu cần

### 4. **Chỉ xử lý sparse days có 1 lecture**
- BEFORE: `if sparse_count != 1`
- AFTER: `if sparse_count > 2` → xử lý cả days với 1-2 lectures

## Kết quả sau fixes

| Metric | Before | After (120s) | Improvement |
|--------|--------|--------------|-------------|
| **S7** | 78     | 72           | **-6 (7.7%)** |
| S6     | 5      | 2            | -3 ✓ |
| S8     | 5      | 12           | +7 ✗ |
| Total  | 88     | 86           | -2 |

### Debug Statistics (500 calls)
- Success rate: **99.8%** 
- move_failed: 7,461 attempts
- swap_failed: 858 attempts
- S7 total fluctuation: 64 → 73 (instability during search)

## Vấn đề còn tồn tại

### 1. **S8 (Teacher Preferences) tăng**
- S8 tăng từ 5 → 12 khi tối ưu S7
- Moves consolidate lectures nhưng vi phạm preferred periods
- **Cần**: Check teacher preferences trong MOVE logic

### 2. **Delta threshold vẫn reject nhiều moves**
- 7,461 move attempts failed do delta > 15.0
- Có thể cần **adaptive threshold** dựa vào phase của search
- Hoặc tăng threshold lên 20.0-25.0 trong phase đầu

### 3. **min_feasible_days calculation có thể chưa chính xác**
- Hiện tại: Greedy packing dựa trên preferred periods
- Không tính đến conflicts (unavailability, curriculum conflicts)
- Có thể làm algorithm target impossibly low min_days

### 4. **Không ưu tiên moves giảm S7 nhiều nhất**
- Hiện tại: Return first valid move found
- **Nên**: Evaluate top 5-10 moves, chọn move có S7 reduction cao nhất

## Recommendations

### Cải thiện ngắn hạn
1. ✅ Tăng threshold lên **20.0** cho aggressive S7 optimization
2. ✅ Filter moves vi phạm teacher preferences (giảm S8)
3. ✅ Evaluate multiple candidate moves, chọn best delta

### Cải thiện dài hạn
1. **Adaptive threshold**: 
   - Early phase (0-30%): threshold = 25.0 (aggressive)
   - Mid phase (30-70%): threshold = 15.0 (balanced)
   - Late phase (70-100%): threshold = 5.0 (conservative)

2. **Smarter move selection**:
   - Generate top 10 candidate moves
   - Score by: `(S7_reduction * 2.5 - S6_increase * 1.8 - S8_increase * 1.0)`
   - Return best scored move

3. **Better min_feasible_days**:
   - Tính toán dựa trên thực tế conflicts
   - Simulation-based: Thử pack lectures vào preferred periods
   - Cache results để tránh recompute

4. **Multi-lecture MOVE**:
   - Thay vì move 1 lecture, thử move 2-3 lectures cùng lúc
   - Có thể empty một sparse day hoàn toàn

## Code Changes Summary

### Modified Functions
1. `TeacherWorkingDaysNeighborhood._find_free_slots()` - Fixed logic bug
2. `TeacherWorkingDaysNeighborhood.generate_candidate()` - Added debug tracking, improved SWAP
3. Threshold: `5.0` → `15.0` (3 places)

### Added Features
- Debug statistics tracking (`_call_count`, `_success_count`, `_failure_reasons`)
- Periodic debug logging every 100 calls
- Two-phase SWAP: same-teacher first, then other-teachers fallback
- Handle sparse days with 1-2 lectures (not just 1)

## Next Steps
1. Test với threshold = 20.0
2. Thêm teacher preference checking trong MOVE
3. Implement adaptive threshold based on search phase
4. Evaluate multiple candidates before returning move
