"""
Utility functions for scheduling
"""
