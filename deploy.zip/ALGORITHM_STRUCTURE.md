# Cấu trúc Thuật toán Lai trong algo_new.py

## ❌ KHÔNG phải thuật toán lai kết hợp SA + TS

Nhìn vào code của `run_metaheuristic()` (dòng 2200):

```python
def run_metaheuristic(state, meta, rng, logger, remaining_time):
    # ...
    if meta.upper() == "TS":
        search = TabuSearch(state, neighborhoods, rng, logger)
    else:
        search = SimulatedAnnealing(state, neighborhoods, rng, logger)
    
    best_assignments, best_breakdown = search.run(...)
    return best_assignments, best_breakdown
```

**Điểm quan trọng**: Chỉ **một trong hai** thuật toán được chạy dựa trên tham số `--meta`:
- Nếu `--meta TS` → Chạy **Tabu Search**
- Nếu `--meta SA` (mặc định) → Chạy **Simulated Annealing**

---

## ✅ "Hybrid" là từ để chỉ cấu trúc CHUNG, không phải SA + TS kết hợp

Thuật toán **thực sự** là "hybrid" vì:

### 1. **Hybrid Constraint-based + Local Search**
   - **Constraint-based**: `build_initial_solution()` xây dựng lời giải ban đầu bằng **backtracking + constraint propagation**
   - **Local Search**: `run_metaheuristic()` cải thiện lời giải bằng **local search operators** (SA hoặc TS)
   
   → Hai giai đoạn: **Xây dựng** (constraint) + **Cải thiện** (local search)

### 2. **Hybrid Neighborhoods** 
   Cả SA và TS đều dùng chung **8 neighborhood operators**:
   ```python
   neighborhoods = [
       MoveLectureNeighborhood(),           # Di chuyển 1 tiết
       SwapLecturesNeighborhood(),          # Hoán đổi 2 tiết
       RoomChangeNeighborhood(),            # Đổi phòng
       PeriodChangeNeighborhood(),          # Đổi thời gian
       KempeChainNeighborhood(),            # Chuỗi Kempe
       CapacityFixNeighborhood(),           # Sửa dung tích
       ConsecutiveGapFillingNeighborhood(), # Lấp khe hổng
       SwapForPairingNeighborhood(),        # Ghép cặp tiết
   ]
   ```
   
   → Cùng một bộ operators, nhưng **cách tìm kiếm khác nhau** (SA vs TS)

### 3. **Hybrid Adaptive Mechanism**
   Cả SA và TS đều:
   - Dùng `NeighborhoodManager` để **chọn operator thích hợp**
   - Theo dõi hiệu suất từng operator → **adaptively reward/penalize**
   - Điều chỉnh tham số dựa trên performance (SA: giảm nhiệt độ, TS: tăng tenure)

---

## 📊 So sánh SA vs TS trong algo_new.py

| Khía cạnh | Simulated Annealing | Tabu Search |
|-----------|-------------------|-------------|
| **Khởi đầu** | `start_temp = max_cost / num_lectures` | `base_tenure = 7` |
| **Chấp nhận move** | Xác suất: `exp(-delta / temp)` | Tốt nhất hoặc aspiration |
| **Tránh lặp** | Giảm nhiệt độ (cooling) | Tabu list + tenure |
| **Quay lại tìm kiếm** | Tăng nhiệt độ khi stagnant | Tăng tenure khi no_improve > 250 |
| **Tuning** | `alpha=0.995, min_temp=0.05` | `tenure=7±4, sample_size=20` |

---

## 🏗️ Luồng thực thi

```
main()
├── build_initial_solution()  ← CONSTRAINT-BASED (backtracking)
│   └── Greedy-cprop hoặc Random-repair
│
└── run_metaheuristic()  ← LOCAL SEARCH
    ├── Nếu --meta TS → TabuSearch.run()
    │   ├── Lặp: Sinh 20 candidates
    │   ├── Chọn tốt nhất (non-tabu hoặc aspiration)
    │   └── Cập nhật tabu list
    │
    └── Nếu --meta SA (default) → SimulatedAnnealing.run()
        ├── Lặp: Sinh 1 candidate
        ├── Quyết định chấp nhận theo xác suất
        └── Giảm nhiệt độ
```

---

## 🎯 Kết luận

1. **Không kết hợp SA + TS**: Chỉ dùng **một trong hai** tại một thời điểm
2. **"Hybrid" có nghĩa**:
   - Kết hợp **constraint-based construction** + **local search optimization**
   - Kết hợp **nhiều neighborhood operators** trong cùng một tìm kiếm
   - Kết hợp **adaptive mechanisms** (reward neighborhoods dựa trên hiệu suất)

3. **Ưu điểm**:
   - ✅ Xây dựng lời giải chất lượng cao ban đầu (tránh rơi vào bad local optima)
   - ✅ Có 8 operators khác nhau để explore không gian lời giải
   - ✅ Adaptively học operator nào hiệu quả nhất
   - ✅ Cho phép chọn chiến lược (SA hoặc TS) tùy theo bài toán

---

## 💡 Nếu muốn hybrid thực sự (SA + TS kết hợp):

Có thể sửa `run_metaheuristic()` thành:

```python
def run_metaheuristic(...):
    # Giai đoạn 1: Simulated Annealing (50% thời gian)
    search = SimulatedAnnealing(state, neighborhoods, rng, logger)
    best_assignments, best_breakdown = search.run(
        best_assignments, best_breakdown, start_time, time_limit * 0.5
    )
    
    # Giai đoạn 2: Tabu Search (50% thời gian còn lại)
    search = TabuSearch(state, neighborhoods, rng, logger)
    best_assignments, best_breakdown = search.run(
        best_assignments, best_breakdown, start_time, time_limit * 0.5
    )
    
    return best_assignments, best_breakdown
```

**Nhưng hiện tại code không làm điều này** → Chỉ chạy **một** trong hai.
