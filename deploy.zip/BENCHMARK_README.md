# Benchmark Tools for Scheduling Algorithm

## Quick Start

### 1. Run benchmarks with default settings
```bash
python benchmark_runner.py
```

This will run 4 configurations:
- Time limits: 100s, 300s, 600s, 1000s
- Seed: 42 (default)
- Instance: dot1.ctt

### 2. Run benchmarks with custom settings
```bash
# Test multiple seeds
python benchmark_runner.py --seeds 42 100 200

# Test specific time limits
python benchmark_runner.py --time-limits 100 300

# Use different instance
python benchmark_runner.py --instance dot2.ctt

# Use Simulated Annealing instead of Tabu Search
python benchmark_runner.py --meta SA
```

### 3. Visualize results
```bash
python visualize_benchmark.py --input benchmark_results.json
```

### 4. Export to CSV for external analysis
```bash
python visualize_benchmark.py --input benchmark_results.json --csv results.csv
```

## Output Files

- **benchmark_results.json**: Complete results with all metrics
- **test_dot1_t100_s42.sol**: Solution file for time=100s, seed=42
- **test_dot1_t300_s42.sol**: Solution file for time=300s, seed=42
- **test_dot1_t600_s42.sol**: Solution file for time=600s, seed=42
- **test_dot1_t1000_s42.sol**: Solution file for time=1000s, seed=42

## Metrics Tracked

### Hard Constraints (must be 0)
- Violations of Lectures
- Violations of Conflicts
- Violations of Availability
- Violations of RoomOccupation
- Violations of RoomType
- Violations of Equipment

### Soft Constraints (minimize)
- **S7**: Teacher Working Days (main optimization target)
- **S8**: Teacher Preferences
- **S6**: Teacher Lecture Consolidation
- Curriculum Compactness
- Lecture Consecutiveness
- Room Stability

## Example Output

```
======================================================================
BENCHMARK RESULTS COMPARISON
Timestamp: 2025-11-12 10:30:00
Total Runs: 4 | Successful: 4
======================================================================

Rank   Time(s)   Seed   Total      S7    S8    S6  Compact  Consec Stability
------ -------- ------ ------- ----- ----- ----- -------- ------- ---------
🏆1       1000     42      56    19    22     9      186       0         0
🥈2        600     42      61    19    27    15      194       0         0
🥉3        300     42      61    19    29    13      186       0         0
  4        100     42      65    25    22     9      222       0         0

======================================================================
BEST RESULT: Config(time=1000s, seed=42)
======================================================================
Total Cost: 56
Elapsed Time: 998.45s

Soft Costs Breakdown:
  curriculum_compactness        :   186
  teacher_consolidation         :     9
  teacher_preferences           :    22
  teacher_working_days          :    19
```

## Advanced Usage

### Test reproducibility with multiple seeds
```bash
python benchmark_runner.py --seeds 42 100 200 300 400 --time-limits 600
```

### Quick test run
```bash
python benchmark_runner.py --time-limits 60 --seeds 42
```

### Production-quality run
```bash
python benchmark_runner.py --time-limits 300 600 1000 1800 3600 --seeds 42 100 200
```

## Tips

1. **Longer time limits** generally produce better results but with diminishing returns
2. **Different seeds** can produce significantly different results due to randomization
3. **S7 (Teacher Working Days)** is weighted heavily (2.5x) in the objective function
4. The visualization tool automatically ranks results and highlights best performers
5. CSV export enables analysis in Excel, pandas, or other tools
