# Hướng Dẫn Sử Dụng Chức Năng Xuất Excel

## Tổng Quan

Hệ thống đã được tích hợp chức năng xuất dữ liệu ra file Excel (.xlsx) cho tất cả các bảng dữ liệu.

## Cách Sử Dụng

### Phương pháp 1: Xuất từ Django Admin

1. **Đăng nhập vào trang Admin**
   - Truy cập: `http://localhost:8000/admin/`
   
2. **Chọn bảng dữ liệu cần xuất**
   - Ví dụ: Scheduling > Giảng viên

3. **Chọn các bản ghi cần xuất**
   - Tick vào checkbox của các dòng cần xuất
   - Hoặc tick vào checkbox ở header để chọn tất cả


### Phương pháp 2: Xuất tất cả dữ liệu

- Nếu muốn xuất toàn bộ, không cần tick checkbox
- Chọn action "Xuất Excel (.xlsx)" và click Go
- Hệ thống sẽ xuất tất cả dữ liệu hiện tại (có thể bị giới hạn bởi phân trang)

## Các Bảng Được Hỗ Trợ

### ✅ Đã tích hợp xuất Excel:

1. **Khoa** - Danh sách khoa
   - Mã khoa, Tên khoa

2. **Bộ Môn** - Danh sách bộ môn
   - Mã bộ môn, Tên bộ môn, Khoa

3. **Giảng Viên** - Danh sách giảng viên
   - Mã GV, Tên, Bộ môn, Khoa, Loại GV, Email, Ghi chú

4. **Môn Học** - Danh sách môn học
   - Mã môn, Tên môn, Tín chỉ, LT, TH, BT

5. **Phòng Học** - Danh sách phòng học
   - Mã phòng, Tên phòng, Loại, Sức chứa, Cơ sở, Ghi chú

6. **Lớp Môn Học** - Danh sách lớp môn học
   - Mã lớp, Môn học, Loại lớp, Sĩ số, Dự kiến ĐT

7. **Phân Công** - Danh sách phân công giảng dạy
   - Mã phân công, Lớp MH, Môn học, Giảng viên, Bộ môn, Số tiết

8. **Thời Khóa Biểu** - Lịch học chi tiết
   - Mã TKB, Lớp MH, Môn học, Giảng viên, Phòng, Thứ, Tiết, Đợt xếp

9. **Nguyện Vọng** - Nguyện vọng giảng viên
   - Mã NV, Giảng viên, Bộ môn, Đợt xếp, Thứ, Tiết, Loại NV

10. **Đợt Xếp** - Danh sách đợt xếp lịch
    - Mã đợt, Tên đợt, Dự kiến ĐT, Ngày BĐ/KT, Trạng thái

## Định Dạng File Excel

### Đặc điểm:
- ✅ Header màu xanh đậm (#0066CC) với chữ trắng, in đậm
- ✅ Border cho tất cả các ô
- ✅ Tự động điều chỉnh độ rộng cột
- ✅ Freeze header row (cố định dòng đầu tiên)
- ✅ Định dạng ngày giờ: DD/MM/YYYY HH:MM
- ✅ Tên file tự động: `[Loại dữ liệu]_YYYYMMDD_HHMMSS.xlsx`

### Ví dụ tên file:
- `Danh_sach_Giang_Vien_20251223_163045.xlsx`
- `Thoi_Khoa_Bieu_20251223_163050.xlsx`

## Thư Viện Sử Dụng

```python
openpyxl>=3.0.9  # Đã có trong requirements.txt
```

## Cấu Trúc Code

### File chính:
- **`apps/scheduling/utils/excel_export.py`** - Utility class ExcelExporter
- **`apps/scheduling/admin.py`** - Tích hợp action vào ModelAdmin

### Cách mở rộng:

Để thêm export cho model mới:

```python
# 1. Trong excel_export.py
@staticmethod
def export_my_model(queryset):
    fields = ['field1', 'field2', 'related.field']
    headers = ['Header 1', 'Header 2', 'Related Field']
    filename = f'My_Model_{datetime.now().strftime("%Y%m%d_%H%M%S")}'
    return ExcelExporter.export_queryset(queryset, fields, headers, filename)

# 2. Trong admin.py
@admin.register(MyModel)
class MyModelAdmin(BaseAdmin):
    actions = ['export_to_excel']
```

## Lưu Ý

1. **Phân trang**: Nếu bảng có nhiều dữ liệu, cần tăng `list_per_page` trong admin hoặc export theo batch
2. **Performance**: Với bảng lớn (>10,000 rows), có thể mất vài giây để generate file
3. **Related Fields**: Hỗ trợ dot notation (VD: `ma_khoa.ten_khoa`) để lấy dữ liệu từ bảng liên quan
4. **Callable Fields**: Tự động gọi method nếu field là function

## Troubleshooting

### Lỗi "openpyxl not found"
```bash
pip install openpyxl
```

### File Excel bị lỗi encoding
- File đã sử dụng UTF-8 encoding
- Mở bằng Microsoft Excel hoặc LibreOffice Calc

### Không thấy action "Xuất Excel"
- Kiểm tra `actions = ['export_to_excel']` trong ModelAdmin
- Đảm bảo đã import ExcelExporter

## Liên Hệ

Nếu cần hỗ trợ hoặc thêm tính năng mới, vui lòng liên hệ team phát triển.
