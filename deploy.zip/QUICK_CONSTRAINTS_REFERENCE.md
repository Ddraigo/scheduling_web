# 🔍 Quick Constraints Reference - algo_new.py

## Hard Constraints (8) - BẮط BUỘC

| # | Tên | Vị Trí | Dòng | Loại | Ghi Chú |
|----|-----|--------|------|------|---------|
| 1 | Period Availability | `_can_place()` | 774-776 | Hard | Không xếp vào slot cấm |
| 2 | Room Availability | `_can_place()` | 778-780 | Hard | 1 phòng = 1 tiết |
| 3 | Teacher Conflict | `_can_place()` | 782-786 | Hard | GV không dạy 2 lớp cùng lúc |
| 4 | Curriculum Conflict | `_can_place()` | 788-792 | Hard | Ngành không trùng tiết |
| 5 | Room Capacity | `_can_place()` | 794-798 | Hard | Phòng đủ chỗ (HC-03) |
| 6 | Room Type Match | `_can_place()` | 800-804 | Hard | LT→LT, TH→TH (HC-05/06) |
| **7** | **Equipment** | **`_can_place()`** | **806-814** | **Hard** | **Phòng có thiết bị cần (NEW)** |
| **8** | **Teacher Prefs** | **`_can_place()`** | **816-821** | **Hard** | **GV chỉ xếp slot nguyện vọng (NEW)** |

## Soft Constraints (4) - ƯU TIÊN

| # | Tên | Dòng | Penalty | Ghi Chú |
|----|-----|------|---------|---------|
| S1 | Min Working Days | 629-633 | 5/ngày thiếu | Phân bổ tiết đều ngày |
| S2 | Room Stability | 635-640 | **20/phòng thêm** | **CỰC NẶNG** |
| S3 | Curriculum Compactness | 642-648 | 2/slot cô lập | Xếp liền nhau trong ngày |
| S4 | Course Consecutiveness | 649-706 | 3-30 | Quy tắc tiết học phổ thông |

## Quick Lookup

**Cần check cái gì?** → Tìm ở `_can_place()` dòng 774-821

**Cần tính penalty?** → Tìm trong `_insert_assignment()`:
- S1: `_compute_course_mwd_penalty()`
- S2: `_compute_course_room_penalty()`
- S3: `_compute_curriculum_day_penalty()`
- S4: `_compute_course_consecutiveness_penalty()`

**Tất cả penalties** được cộng lại trong `current_cost` property
