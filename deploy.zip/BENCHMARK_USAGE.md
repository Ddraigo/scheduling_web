# Hướng Dẫn Sử Dụng Benchmark System

## Tổng Quan

Hệ thống benchmark đã được tích hợp với **validator.py** hiện có (thay vì tạo validator mới) để đảm bảo tính nhất quán và chính xác của việc kiểm tra ràng buộc.

## Các File Quan Trọng

1. **validator.py** - Validator gốc (ITC-2007 compatible)
   - Kiểm tra 6 hard constraints và 8 soft constraints
   - Được benchmark_runner.py gọi để validate solution
   
2. **benchmark_runner.py** - Script chạy benchmark tự động
   - Chạy solver với nhiều cấu hình khác nhau
   - Gọi validator.py để validate từng solution
   - Lưu kết quả vào JSON

3. **visualize_benchmark.py** - Script trực quan hóa kết quả
   - In bảng so sánh chi tiết
   - Phân tích theo time_limit và seed
   - Vẽ biểu đồ constraint violations (CHỈ hiển thị constraint > 0)

## Cách Sử Dụng

### 1. Chạy Benchmark

```bash
# Chạy với nhiều time_limits và seed cố định
python benchmark_runner.py --time-limits 100 300 600 1000 --seeds 42

# Chạy với time_limit cố định và nhiều seeds
python benchmark_runner.py --time-limits 600 --seeds 42 123 456

# Chạy với nhiều cấu hình
python benchmark_runner.py --time-limits 100 300 600 --seeds 42 123
```

**Output**: `benchmark_results.json` chứa toàn bộ kết quả

### 2. Xem Kết Quả (Bảng + Phân Tích)

```bash
# Xem tất cả phân tích
python visualize_benchmark.py

# Chỉ định file input khác
python visualize_benchmark.py --input my_results.json

# Xuất CSV
python visualize_benchmark.py --csv results.csv
```

### 3. Vẽ Biểu Đồ (CHỈ Constraint > 0)

```bash
# Cài đặt matplotlib (nếu chưa có)
pip install matplotlib

# Tạo biểu đồ
python visualize_benchmark.py --charts

# Chỉ định thư mục output
python visualize_benchmark.py --charts --output-dir my_charts
```

**Output Charts**:
- `constraint_violations.png` - Biểu đồ tất cả constraint có vi phạm
  - Hard violations (đỏ) - nếu có
  - Soft costs (vàng/cam) - nếu có
- `teacher_constraints.png` - Biểu đồ riêng cho S6, S7, S8 (nếu có)

**Lưu ý**: Nếu TẤT CẢ constraints = 0 → Không vẽ biểu đồ (in thông báo "No violations found")

## Kết Quả Benchmark

### Metrics Được Theo Dõi

#### Hard Constraints (Phải = 0)
- Lectures: Tất cả bài giảng phải được xếp
- Conflicts: Không xung đột giảng viên/curriculum
- Availability: Không xếp vào slot unavailable
- RoomOccupation: Mỗi phòng chỉ 1 lớp/slot
- RoomType: Phòng LT cho LT, phòng TH cho TH
- Equipment: Phòng có đủ thiết bị

#### Soft Constraints (Minimize)
- RoomCapacity (S1): Phòng đủ chỗ
- MinWorkingDays (S2): Đủ số ngày tối thiểu
- CurriculumCompactness (S3): Các buổi liền kề
- RoomStability (S4): Ít đổi phòng
- LectureConsecutiveness (S5): 2 tiết liền nhau
- **TeacherConsolidation (S6)**: GV ít đổi phòng giữa các tiết
- **TeacherWorkingDays (S7)**: GV ít ngày đến trường
- **TeacherPreferences (S8)**: Xếp theo preference GV

## Ví Dụ Output

### Bảng So Sánh
```
====================================================================================================
BENCHMARK RESULTS COMPARISON
Timestamp: 2025-01-15 10:30:00
Total Runs: 4 | Successful: 4
====================================================================================================

Rank   Feas  Time(s)   Seed   Total    S7   S8   S6 Compact HardViol
------ ----- -------- ------ ------- ----- ----- ----- -------- ---------
🏆1       ✓      600     42     255    19   27   15      194         0
🥈2       ✓      300     42     267    21   28   15      203         0
🥉3       ✓     1000     42     270    19   29   16      206         0
  4       ✓      100     42     289    23   30   17      219         0
```

### Biểu Đồ
- **Nếu có vi phạm**: Vẽ biểu đồ cột (bar chart) với màu sắc phân biệt
  - Đỏ: Hard violations
  - Vàng/Cam: Soft costs
- **Nếu KHÔNG có vi phạm**: In thông báo "✓ No constraint violations found"

## Thay Đổi So Với Phiên Bản Trước

### ✅ Cải Tiến
1. **Sử dụng validator.py hiện có** thay vì tạo validate_solution.py mới
   - Tránh trùng lặp code
   - Đảm bảo logic validation chính xác
   - Tương thích với ITC-2007 format

2. **Biểu đồ thông minh**
   - CHỈ hiển thị constraint > 0
   - Không vẽ biểu đồ nếu tất cả = 0
   - Tự động điều chỉnh layout

3. **Validator API**
   - Thay đổi từ `--instance --solution` sang positional args
   - Xử lý return code linh hoạt (validator.py trả về 1 nếu infeasible)

### 🗑️ File Đã Xóa
- `validate_solution.py` - Không cần thiết vì đã có validator.py

## Troubleshooting

### Lỗi "Validator not found"
- Đảm bảo file `validator.py` nằm cùng thư mục với benchmark_runner.py

### Lỗi "matplotlib not available"
```bash
pip install matplotlib
```

### Biểu đồ không xuất hiện
- Kiểm tra xem có constraint > 0 không
- Nếu tất cả = 0, không có biểu đồ (đây là hành vi đúng)

## Liên Hệ

Nếu có vấn đề, kiểm tra:
1. validator.py có chạy được standalone không: `python validator.py instance.ctt solution.sol`
2. benchmark_results.json có dữ liệu không
3. Log output của benchmark_runner.py
