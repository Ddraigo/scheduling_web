# Câu Trả Lời: "Hybrid" trong algo_new.py là gì?

## TL;DR - Tóm tắt ngắn gọn

**Câu hỏi:** algo_new.py chạy SA và TS riêng biệt hay kết hợp? Nếu không kết hợp sao gọi là "hybrid"?

**Đáp án:**

### ❌ KHÔNG kết hợp SA + TS
- Chỉ chạy **một trong hai**:
  - `python algo_new.py --meta SA` → Chạy **Simulated Annealing**
  - `python algo_new.py --meta TS` → Chạy **Tabu Search**
- Code `run_metaheuristic()` (dòng 2200): `if meta == "TS": search = TabuSearch() else: search = SimulatedAnnealing()`

### ✅ "Hybrid" có 3 lớp ý nghĩa

#### 1️⃣ **Hybrid Constraint + Local Search**
```
Giai đoạn 1: build_initial_solution()
└─ Dùng CONSTRAINT PROPAGATION + BACKTRACKING
   Xây dựng lời giải chất lượng cao ban đầu

Giai đoạn 2: run_metaheuristic()
└─ Dùng LOCAL SEARCH (SA hoặc TS)
   Cải thiện lời giải từ ban đầu
```

#### 2️⃣ **Hybrid Multiple Neighborhoods**
- Cả SA và TS chia sẻ **8 neighborhood operators**:
  ```
  MoveLectureNeighborhood
  SwapLecturesNeighborhood
  RoomChangeNeighborhood
  PeriodChangeNeighborhood
  KempeChainNeighborhood
  CapacityFixNeighborhood
  ConsecutiveGapFillingNeighborhood
  SwapForPairingNeighborhood
  ```
- Dùng `NeighborhoodManager` để **thích ứng chọn operator** tốt nhất

#### 3️⃣ **Hybrid Adaptive Mechanisms**
- **SA**: Giảm nhiệt độ theo công thức, tăng lại nếu bị kẹt
- **TS**: Điều chỉnh tenure (dài/ngắn) dựa trên hiệu suất

---

## 📊 So sánh SA vs TS (Cách làm việc)

| | **Simulated Annealing** | **Tabu Search** |
|---|---|---|
| **Candidates/iteration** | 1 ngẫu nhiên | 20 tốt nhất |
| **Quyết định** | Xác suất: `exp(-delta/T)` | Chọn best non-tabu hoặc aspiration |
| **Memory** | Không (chỉ nhiệt độ) | Có (tabu list) |
| **Thoát local optima** | Xác suất chấp nhận moves xấu | Tabu list + aspiration |
| **Ứng phó khi bị mắc** | Tăng T lại (`T *= 1.5`) | Tăng tenure (`tenure += 1`) |

---

## 🔍 Minh họa: 1 Iteration

### **SA (Iteration 1523)**
```
├─ Sinh 1 move: Swap c0050 ↔ c0089 (delta = -2)
├─ delta ≤ 0 → CHẤP NHẬN (luôn)
├─ Áp dụng: cost 124 → 122
└─ Giảm T: 15.8 * 0.995 = 15.721
```

### **TS (Iteration 523)**
```
├─ Sinh 20 candidates
│  ├─ Best non-tabu: Swap, delta = -3
│  ├─ Second best: PeriodChange, delta = -1
│  └─ ...
├─ Chọn Swap (best + non-tabu)
├─ Áp dụng: cost 124 → 121
└─ Cập nhật tabu: disallow swap 50↔89 cho 7-10 iterations
```

---

## 💡 Lý do gọi là "Hybrid"

```
🏗️ HYBRID = Kết hợp nhiều kỹ thuật, không phải (SA + TS chung lúc)

1. Constraint-based (construction) + Local Search (improvement)
   ✅ Xây dựng tốt ban đầu → Tìm kiếm cố gắng cải thiện

2. 8 Neighborhoods + Adaptive Manager
   ✅ Không dùng một di chuyển duy nhất
   ✅ Thích ứng chọn di chuyển nào hiệu quả

3. Adaptive cooling (SA) / Adaptive tenure (TS)
   ✅ Tham số tự điều chỉnh dựa trên hiệu suất
```

---

## ⚠️ Nếu muốn SA + TS thực sự kết hợp?

Sửa `run_metaheuristic()`:

```python
def run_metaheuristic(state, meta, rng, logger, remaining_time):
    half_time = remaining_time * 0.5
    
    # Giai đoạn 1: Simulated Annealing (50% thời gian)
    search_sa = SimulatedAnnealing(state, neighborhoods, rng, logger)
    best_a, best_b = search_sa.run(best_a, best_b, start_time, half_time)
    
    # Giai đoạn 2: Tabu Search (50% thời gian còn lại)
    search_ts = TabuSearch(state, neighborhoods, rng, logger)
    best_a, best_b = search_ts.run(best_a, best_b, start_time, half_time)
    
    return best_a, best_b
```

**Nhưng hiện tại code KHÔNG làm điều này** → Chỉ một trong hai.

---

## 🎯 Kết luận

✅ **"Hybrid" trong algo_new.py = Constraint + Local Search + Multiple Neighborhoods**

❌ **KHÔNG = SA + TS chung lúc** (chỉ chạy một)

💡 **Ưu điểm:**
- Xây dựng tốt → Tìm kiếm hữu ích hơn
- 8 operators → Linh hoạt tìm kiếm
- Adaptively chọn operator → Tự học cái gì tốt
- Cho phép chọn chiến lược (SA hoặc TS) tùy theo bài toán

🚀 **Khuyến nghị cho bài toán CTT:**
- **TS tốt hơn** SA do tìm kiếm hiệu quả + tabu memory
- Nhưng có thể thử SA + TS tuần tự để so sánh
