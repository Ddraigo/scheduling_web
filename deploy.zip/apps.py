from django.apps import AppConfig


class SapLichConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.sap_lich'
    verbose_name = 'Sắp lịch'
