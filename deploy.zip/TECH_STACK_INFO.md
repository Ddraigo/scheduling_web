# THÔNG TIN CÔNG NGHỆ HỆ THỐNG XẾP LỊCH HỌC

## I. CÁC CÔNG NGHỆ (2.2)

### 2.2.1 Backend Framework

**Ngôn ngữ & Framework:**
- Python 3.9-3.11 + Django 5.2.6
- Django REST Framework 3.15.2 (cho API)

**Vai trò Backend:**
- Xử lý logic xếp lịch và ràng buộc
- Gọi thuật toán meta-heuristic (trong `apps/scheduling/algorithms/`)
- Tích hợp LLM API (Gemini) cho chatbot hỏi đáp
- Quản lý CSDL thời khóa biểu (CRUD operations)
- API RESTful cho frontend và external services
- Xử lý nghiệp vụ: phân công giảng viên, quản lý phòng học, timeslot

**Lý do chọn Django:**
- Framework full-stack với ORM mạnh mẽ (quản lý quan hệ phức tạp: Khoa-BoMon-GiangVien-MonHoc-PhongHoc-LopMonHoc-ThoiKhoaBieu)
- Admin UI tích hợp sẵn (Django Admin với Jazzmin theme)
- Bảo mật tốt (CSRF, Authentication, Authorization)
- Cộng đồng lớn, nhiều thư viện hỗ trợ
- Django REST Framework giúp xây dựng API nhanh
- So với FastAPI: Django phù hợp hơn cho dự án có admin panel và quản lý dữ liệu phức tạp

**Ví dụ API quan trọng:**
- `/api/scheduling/khoa/` - Quản lý Khoa
- `/api/scheduling/bomon/` - Quản lý Bộ môn  
- `/api/scheduling/giangvien/` - Quản lý Giảng viên
- `/api/scheduling/monhoc/` - Quản lý Môn học
- `/api/scheduling/phonghoc/` - Quản lý Phòng học
- `/api/scheduling/lopmonhoc/` - Quản lý Lớp môn học
- `/api/scheduling/tkb/` - CRUD Thời khóa biểu
- `/api/scheduling/chatbot/` - Chat với LLM về lịch học
- CLI command: `python manage.py generate_schedule` - Chạy thuật toán xếp lịch

### 2.2.2 Frontend Framework

**Frontend sử dụng:**
- Django Templates (Server-side rendering)
- HTML/CSS/JavaScript thuần
- Vite 6.2.0 (build tool cho assets)
- SASS 1.85.1 (CSS preprocessor)
- Bootstrap (UI framework)
- jQuery (DOM manipulation, AJAX)

**Frontend đảm nhiệm:**
- Hiển thị thời khóa biểu (dạng lưới theo tuần/ngày)
- Giao diện admin quản lý dữ liệu (Django Admin custom)
- Form nhập liệu môn học, giảng viên, phòng
- Giao diện chatbot hỏi đáp về lịch học (WebSocket/AJAX)
- Import/Export Excel
- Charts/Reports (Django Charts app)

**Lý do chọn:**
- Không cần SPA phức tạp (React/Vue) vì đây là admin system
- Django Templates đủ mạnh cho CRUD operations
- SSR giúp SEO tốt, load nhanh lần đầu
- Tích hợp trực tiếp với Django backend, ít phức tạp hơn
- Dễ bảo trì với team nhỏ

**Ví dụ sử dụng:**
- Màn hình hiển thị TKB: `/scheduling/tkb/` với grid view
- Admin panel: `/admin/scheduling/` (CRUD cho tất cả models)
- Chatbot UI: Tích hợp trong dashboard

### 2.2.3 Mô hình Ngôn ngữ Lớn (LLM)

**LLM sử dụng:**
- **Google Gemini 2.5 Pro** (qua API)
- Backup: Anthropic Claude (có trong requirements.txt)

**Vai trò LLM:**
- **Chatbot hỏi đáp:** Trả lời câu hỏi về lịch giảng viên, phòng trống, lớp học
- **Tra cứu thông tin:** Query database dựa trên natural language
- **Giải thích TKB:** Giải thích tại sao lịch được xếp như vậy
- **Tư vấn:** Gợi ý phòng phù hợp, timeslot trống

**LLM KHÔNG làm gì:**
- ❌ **KHÔNG phải solver** - LLM không giải bài toán xếp lịch
- ❌ Không tạo ra lịch học (việc này do thuật toán meta-heuristic đảm nhiệm)
- ❌ Không tối ưu hóa ràng buộc

**Lý do chọn Gemini:**
- Hỗ trợ tiếng Việt tốt
- API free tier rộng rãi (cho dự án sinh viên)
- Tốc độ phản hồi nhanh
- Context window lớn (có thể nhét nhiều dữ liệu lịch)
- Ổn định, uptime cao

**Kiến trúc LLM:**
```
apps/scheduling/services/
├── chatbot_service.py       # ScheduleChatbot class - main interface
├── llm_service.py            # LLMDataProcessor - format data cho LLM
└── data_access_layer.py      # Lấy data từ DB
```

### 2.2.4 Cơ sở Dữ liệu và Lưu trữ

**Database:**
- **Microsoft SQL Server** (mssql-django 1.6, pyodbc 5.2.0)
- Driver: ODBC Driver 17 for SQL Server
- Database name: `CSDL_TKB`

**Lưu trữ:**
- **Môn học:** tb_MON_HOC (mã môn, tên, số tín chỉ, loại môn)
- **Giảng viên:** tb_GIANG_VIEN (mã GV, tên, email, bộ môn, loại GV)
- **Phòng học:** tb_PHONG_HOC (mã phòng, loại phòng, sức chứa, thiết bị)
- **Lớp môn học:** tb_LOP_MON_HOC (mã lớp, môn học, nhóm, số SV, số ca/tuần, thiết bị yêu cầu)
- **Thời khóa biểu:** tb_THOI_KHOA_BIEU (lớp, phòng, timeslot, phân công GV)
- **Phân công:** tb_PHAN_CONG (giảng viên được assign vào lớp nào)
- **Khoa/Bộ môn:** tb_KHOA, tb_BO_MON (cấu trúc tổ chức)
- **Timeslot:** tb_TIME_SLOT, tb_KHUNG_THOI_GIAN (thứ, ca, giờ bắt đầu/kết thúc)
- **Đợt xếp:** tb_DOT_XEP (kỳ HK1/HK2, năm học, trạng thái)

**Lý do chọn SQL Server:**
- Yêu cầu của trường đại học (đã có license)
- Quan hệ phức tạp giữa các entity (Khoa → BoMon → GiangVien → PhanCong → TKB)
- ACID compliance cần thiết cho consistency
- Trigger, stored procedure hỗ trợ tốt
- So với NoSQL: Dữ liệu có schema cố định, cần JOIN nhiều

**Đặc điểm:**
- Foreign Key cascading (ON DELETE CASCADE)
- CharField primary keys (ma_khoa, ma_gv, ma_bo_mon) thay vì auto-increment
- Vietnamese column names (ten_mon_hoc, so_luong_sv, ...)

### 2.2.5 Triển khai và Môi trường Chạy

**Triển khai:**
- **Local Development:** Windows (Python 3.11, SQL Server local)
- **Production Ready:** Docker + Docker Compose

**Docker:**
- Có sử dụng Docker
- Dockerfile: Python 3.9 base, Gunicorn WSGI server
- docker-compose.yml: Multi-container setup (web, database)
- Nginx reverse proxy (nginx/ folder)

**Lý do dùng Docker:**
- Consistency giữa dev và production
- Dễ deploy lên cloud (AWS, GCP, Azure)
- Isolate dependencies
- Scalability: có thể thêm containers dễ dàng

**Môi trường:**
- **Development:** Windows 10/11 (VS Code)
- **Production:** Linux/Docker container
- **WSGI Server:** Gunicorn 23.0.0
- **Static Files:** Whitenoise 6.7.0 (serve static trong Django)

**CI/CD (có sẵn config):**
- render.yaml (deploy lên Render.com)
- build.sh (build script)

---

## II. NGUYÊN LÝ & MÔ HÌNH PHẦN MỀM (2.3)

### 2.3.1 Kiến trúc Tổng thể Hệ thống

**Kiến trúc:**
- **Client-Server** architecture
- **Layered** (3-tier): Presentation - Business Logic - Data Access
- **Monolithic** (không phải microservice, nhưng modular apps)

**Các thành phần chính:**

1. **Frontend (Presentation Layer)**
   - Django Templates + Static files (HTML/CSS/JS)
   - Admin UI (Django Admin với Jazzmin)
   - User-facing pages (scheduling views)

2. **Backend (Business Logic Layer)**
   - Django Views & ViewSets (REST API)
   - Services layer:
     - `schedule_generator_llm.py` - Xếp lịch với LLM
     - `chatbot_service.py` - Chatbot hỏi đáp
     - `llm_service.py` - LLM data processor
     - `data_access_layer.py` - Truy vấn DB

3. **Algorithm Solver**
   - `apps/scheduling/algorithms/alo_origin/` - Meta-heuristic algorithms
   - Độc lập, có thể gọi qua CLI hoặc API

4. **LLM Service**
   - External API call đến Google Gemini
   - Async/sync wrapper trong chatbot_service.py

5. **Database Layer**
   - SQL Server (CSDL_TKB)
   - Django ORM models
   - Raw SQL queries khi cần

**Luồng xử lý:**
```
User (Browser) 
  → Django View/API 
    → Service Layer (chatbot_service / schedule_generator_llm)
      → Data Access Layer (ORM queries)
        → SQL Server Database
      → Algorithm Solver (nếu cần xếp lịch)
      → LLM API (nếu cần chatbot)
    → Response JSON/HTML
  → Render UI
```

**Sơ đồ:**
```
┌─────────────────────────────────────────┐
│  CLIENT (Browser)                       │
│  - Django Templates                     │
│  - JavaScript (AJAX)                    │
│  - Admin UI                             │
└────────────┬────────────────────────────┘
             │ HTTP/HTTPS
             ▼
┌─────────────────────────────────────────┐
│  DJANGO BACKEND                         │
│  ┌───────────────────────────────────┐  │
│  │ Views & API (REST Framework)      │  │
│  └───────────┬───────────────────────┘  │
│              │                           │
│  ┌───────────▼───────────────────────┐  │
│  │ Service Layer                     │  │
│  │  - chatbot_service               │  │
│  │  - schedule_generator_llm        │  │
│  │  - llm_service (data processor)  │  │
│  └───────────┬───────────────────────┘  │
│              │                           │
│  ┌───────────▼───────────────────────┐  │
│  │ Data Access Layer (DAL)           │  │
│  │  - Django ORM                     │  │
│  │  - Custom queries                 │  │
│  └───────────┬───────────────────────┘  │
└──────────────┼───────────────────────────┘
               │
      ┌────────┼────────┐
      │        │        │
      ▼        ▼        ▼
 ┌─────────┐ ┌──────────┐ ┌──────────────┐
 │SQL Server│ │Algorithm │ │ LLM Service  │
 │ Database │ │  Solver  │ │ (Gemini API) │
 │ CSDL_TKB │ │(meta-h.) │ │              │
 └──────────┘ └──────────┘ └──────────────┘
```

### 2.3.2 Nguyên lý Tách lớp và Giao tiếp

**Tách lớp (Separation of Concerns):**

1. **Presentation Layer** (Django Templates, Views)
   - Hiển thị UI, nhận input từ user
   - Không chứa business logic

2. **Business Logic Layer** (Services)
   - `chatbot_service.py` - Logic chatbot
   - `schedule_generator_llm.py` - Logic xếp lịch
   - `llm_service.py` - Xử lý dữ liệu cho LLM
   - Không trực tiếp query database

3. **Data Access Layer** (DAL)
   - `data_access_layer.py` - Tất cả queries ở đây
   - Django ORM models
   - Trả về objects/dicts, không biết về business logic

4. **Database Layer**
   - SQL Server schema
   - Triggers, constraints

**Giao tiếp giữa các lớp:**

- **REST API** (JSON)
  - Frontend ↔ Backend: HTTP REST calls
  - Async/Await cho LLM calls

- **Synchronous** trong Django
  - View → Service → DAL → Database (blocking)

- **Message Format:** JSON
  - API responses: `{"status": "success", "data": {...}}`
  - LLM prompts: JSON structured data

**Vì sao tách lớp:**
- **Dễ bảo trì:** Sửa DAL không ảnh hưởng Service
- **Dễ test:** Mock DAL khi test Service
- **Dễ mở rộng:** Thêm cache layer, thay đổi LLM provider
- **Code reuse:** Nhiều views có thể dùng chung Service

**Interface boundaries:**
```python
# View Layer (views.py)
class ChatbotView(APIView):
    def post(self, request):
        chatbot = ScheduleChatbot()  # Service layer
        response = chatbot.chat(...)
        return Response(response)

# Service Layer (chatbot_service.py)
class ScheduleChatbot:
    def chat(self, message, ma_dot):
        data = DataAccessLayer.get_dataset_for_llm(ma_dot)  # DAL
        prompt = self._build_prompt(data)
        llm_response = self.client.generate(...)  # External LLM
        return llm_response

# Data Access Layer (data_access_layer.py)
class DataAccessLayer:
    @staticmethod
    def get_dataset_for_llm(ma_dot):
        dot_xep = DotXep.objects.get(ma_dot=ma_dot)  # ORM
        phan_cong = PhanCong.objects.filter(...)
        return {'dot_xep': dot_xep, 'phan_cong': phan_cong}
```

### 2.3.3 Áp dụng vào Hệ thống Xếp Lịch

**Ví dụ: User yêu cầu xếp lịch cho đợt mới**

1. **Frontend (User action)**
   - User vào `/admin/scheduling/dotxep/`
   - Nhập thông tin đợt xếp (HK1/2024-2025)
   - Click "Xếp lịch tự động"

2. **Backend (Django View)**
   - View nhận request POST `/api/scheduling/generate/`
   - Validate input (ma_dot, constraints)
   - Gọi Service layer: `ScheduleGeneratorLLM.create_schedule_llm(ma_dot)`

3. **Service Layer**
   - `ScheduleGeneratorLLM`:
     - Gọi DAL lấy data: `DataAccessLayer.get_dataset_for_llm(ma_dot)`
     - Chuẩn bị input cho solver: constraints, classes, rooms, timeslots
     - **Gọi Algorithm Solver** (meta-heuristic trong `algorithms/`)
     - Nhận schedule solution từ solver

4. **Algorithm Solver**
   - Chạy meta-heuristic (Genetic Algorithm, Simulated Annealing, ...)
   - Tối ưu hóa theo objective function (minimize conflicts)
   - Trả về schedule assignment: `{class_id: (room, timeslot)}`

5. **Service Layer (tiếp)**
   - Validate solution từ solver
   - **LLM (optional):** Giải thích lịch đã xếp
     - Gọi `LLMService.explain_schedule(schedule, constraints)`
     - LLM trả về: "Lớp X xếp phòng Y vào thứ Z ca T vì..."
   - Lưu vào DB qua DAL: `DataAccessLayer.save_schedule(schedule)`

6. **Data Access Layer**
   - Create/Update `ThoiKhoaBieu` objects
   - Commit transaction
   - Return saved objects

7. **Backend → Frontend**
   - View trả về JSON response:
     ```json
     {
       "status": "success",
       "message": "Xếp lịch thành công cho 150 lớp",
       "schedule_id": "DOT-2024-HK1",
       "stats": {
         "total_classes": 150,
         "conflicts": 0,
         "rooms_used": 45
       }
     }
     ```

8. **Frontend**
   - Nhận response, hiển thị thông báo thành công
   - Redirect đến trang xem TKB

**Ví dụ: User chat với LLM về lịch**

1. **Frontend**
   - User gõ: "Giảng viên Nguyễn Văn A dạy vào thứ mấy?"
   - Send POST `/api/scheduling/chatbot/`

2. **Backend View**
   - `ChatbotView.post()` nhận message
   - Gọi `ScheduleChatbot.chat(message, ma_dot)`

3. **Service Layer (Chatbot)**
   - Parse intent: "query teacher schedule"
   - Gọi DAL: `DataAccessLayer.get_tkb_by_giang_vien('GV001', 'DOT-2024-HK1')`
   - Format data cho LLM prompt
   - **Gọi LLM API (Gemini)**:
     ```
     System: Bạn là trợ lý TKB...
     User: Giảng viên Nguyễn Văn A dạy vào thứ mấy?
     Context: {schedule_data từ DB}
     ```
   - LLM trả về: "Giảng viên Nguyễn Văn A dạy vào Thứ 2 (ca 1-3) và Thứ 5 (ca 7-9)."

4. **Backend → Frontend**
   - Return JSON: `{"reply": "Giảng viên...", "source": "database"}`

5. **Frontend**
   - Hiển thị reply trong chat UI

**Điểm mạnh của kiến trúc:**

✅ **Dễ thay đổi ràng buộc:**
- Thêm constraint mới → sửa trong Service/Solver layer
- Không ảnh hưởng View hay DAL

✅ **Dễ tích hợp LLM:**
- LLM call đóng gói trong Service
- Có thể swap Gemini → Claude chỉ cần sửa `chatbot_service.py`

✅ **Dễ test:**
- Mock DAL → test Service logic
- Mock Service → test View/API

✅ **Separation of Concerns:**
- Solver chỉ lo tối ưu, không biết về DB
- LLM chỉ lo chat, không biết về scheduling algorithm

✅ **Scalability:**
- Có thể tách Solver ra microservice riêng
- Có thể cache DAL queries
- Có thể deploy multi-instance với load balancer

---

## TÓM TẮT NHANH

### Backend
- **Python 3.9-3.11 + Django 5.2.6**
- REST API (Django REST Framework)
- Services: chatbot, schedule generator, LLM integration
- Admin UI: Django Admin + Jazzmin

### Frontend
- **Django Templates (SSR)**
- HTML/CSS/JS + Vite build tool
- Bootstrap UI framework
- No SPA (không cần React/Vue cho admin system)

### LLM
- **Google Gemini 2.5 Pro API**
- Vai trò: Chatbot hỏi đáp, giải thích TKB
- **KHÔNG phải solver** - chỉ tương tác với user

### Database
- **Microsoft SQL Server** (CSDL_TKB)
- Relational schema: Khoa-BoMon-GiangVien-MonHoc-PhongHoc-LopMonHoc-ThoiKhoaBieu
- Django ORM + mssql-django driver

### Algorithm
- **Meta-heuristic solver** (trong `apps/scheduling/algorithms/`)
- Genetic Algorithm / Simulated Annealing / ...
- Gọi qua CLI: `python manage.py generate_schedule`

### Deploy
- **Docker** (Dockerfile + docker-compose.yml)
- Gunicorn WSGI server
- Nginx reverse proxy
- Whitenoise static files
- Target: Local/Cloud (AWS, GCP, Azure)

### Architecture
- **Client-Server, Layered (3-tier)**
- Presentation → Business Logic (Services) → Data Access → Database
- REST API (JSON), Synchronous Django
- Modular apps: `apps/scheduling/`, `apps/sap_lich/`, `apps/charts/`

### Luồng xếp lịch
1. User request (Frontend)
2. Django View/API
3. Service: ScheduleGeneratorLLM
4. DAL: Get data from DB
5. **Algorithm Solver**: Meta-heuristic optimization
6. LLM (optional): Explain schedule
7. DAL: Save schedule to DB
8. Response JSON → Frontend

### Ưu điểm kiến trúc
- Dễ bảo trì (tách lớp rõ ràng)
- Dễ mở rộng (thêm constraint, swap LLM)
- Dễ test (mock DAL, Service)
- Scalable (Docker, multi-instance)
