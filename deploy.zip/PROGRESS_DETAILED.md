# 📊 BÁO CÁO TIẾN ĐỘ CHI TIẾT - DỰ ÁN SCHEDULING

**Ngày cập nhật:** 27/10/2025  
**Trạng thái:** 🔄 Đang phát triển - Giai đoạn 4 (Tối ưu hóa ràng buộc mềm)

---

## 📋 MỤC LỤC
1. [Tổng quan](#tổng-quan)
2. [Hoàn thành](#hoàn-thành)
3. [Đang tiến hành](#đang-tiến-hành)
4. [Kỹ thuật chi tiết](#kỹ-thuật-chi-tiết)
5. [Hiệu năng](#hiệu-năng)
6. [Kế hoạch tiếp theo](#kế-hoạch-tiếp-theo)

---

## 🎯 Tổng quan

### Mục tiêu chính
- ✅ **Cơ sở dữ liệu:** 216 lớp, 201 phòng, 36 giáo viên
- ✅ **Ràng buộc cứng:** Không xung đột, khả dụng GV, không học Chủ Nhật
- ✅ **Ràng buộc mềm:** 6 tiêu chí chất lượng với trọng số riêng
- ✅ **Thuật toán:** CB-CTT (Backtracking ngẫu nhiên)
- 🔄 **Tối ưu hóa:** Giảm vi phạm NguyenVong preferences

### Các giai đoạn đã vượt qua
1. **Giai đoạn 1 (Cơ bản):** Xây dựng cấu trúc dữ liệu, thuật toán cơ bản
2. **Giai đoạn 2 (Khả dụng):** Giải quyết khả dụng giáo viên, loại bỏ lỗi infeasible
3. **Giai đoạn 3 (Đầu ra):** Sửa lỗi JSON output, enable random seed
4. **Giai đoạn 4 (Tối ưu):** Thêm tracking preference violations - **HIỆN TẠI**

---

## ✅ Hoàn thành

### A. Ràng buộc cứng (Hard Constraints)
| Tên | Trạng thái | Chi tiết |
|-----|-----------|---------|
| Không xung đột phòng | ✅ | Mỗi phòng chỉ có 1 lớp/period |
| Không xung đột giáo viên | ✅ | Mỗi GV chỉ dạy 1 lớp/period |
| Không xung đột curriculum | ✅ | Mỗi curriculum chỉ có 1 lớp/period |
| Khả dụng giáo viên (feasible_periods) | ✅ | Cho phép tất cả 35 slots |
| Không học Chủ Nhật (unavailability) | ✅ | Chặn 5 slots Chủ Nhật (period 30-34) |

**Kết quả:** Tất cả 216 lớp được xếp lịch hợp lệ, không vi phạm ràng buộc cứng

### B. Ràng buộc mềm (Soft Constraints)
| Tên | Trọng số | Trạng thái | Hiện tại | Mục tiêu |
|-----|---------|-----------|---------|----------|
| room_capacity | 1 | ✅ | 0 | 0 |
| min_working_days | 1 | ✅ | ~3240 | Giảm xuống |
| curriculum_compactness | 1 | ✅ | ~14 | Tối ưu |
| room_stability | 1 | ✅ | 0 | 0 |
| lecture_clustering | 1 | ✅ | 0 | 0 |
| preference_violations | **10** | 🔄 | ~125 | Giảm xuống |

**Tổng chi phí hiện tại:** ~3254 (99.7% từ min_working_days)

### C. Tính năng chính
| Tính năng | Trạng thái | Mô tả |
|-----------|-----------|--------|
| Load dữ liệu từ DB | ✅ | Load 216 courses, 201 rooms, 36 teachers |
| Build khởi tạo hợp lệ | ✅ | Backtracking với heuristic sắp xếp ưu tiên |
| Xác thực ràng buộc | ✅ | Check hard constraints, tính soft penalties |
| Output JSON | ✅ | Format "Thu2-Ca1" đến "Thu8-Ca5" (chính xác) |
| Random seed | ✅ | Mỗi lần chạy kết quả khác nhau (khi seed=None) |
| Debug logging | ✅ | Log chi tiết từng bước thuật toán |

### D. Sửa lỗi
| Lỗi | Nguyên nhân | Giải pháp | Trạng thái |
|-----|-----------|----------|-----------|
| Infeasible GV004 | Feasible_periods quá ít | Cho phép tất cả slots | ✅ |
| "Thu0-Ca1" sai | day_idx không convert | Thêm +2 → thu (2-8) | ✅ |
| Luôn cùng kết quả | seed=42 cố định | Random seed mỗi lần | ✅ |
| Preference violations không track | Chưa implement | Thêm _compute_preference_violation() | 🔄 |

---

## 🔄 Đang tiến hành

### Giai đoạn 4: Tối ưu hóa Preference Violations

#### Vấn đề
- Hiện tại có ~125 vi phạm NguyenVong preferences
- Meaning: 125 lớp được xếp ngoài khung giờ ưu tiên của GV
- Ảnh hưởng: GV dạy ngoài giờ khoá, sinh viên có thể không thể tham dự

#### Giải pháp
Thêm ràng buộc mềm **preference_violations** với trọng số **10**:
- Khi xếp lớp vào period, check xem có trong `teacher_preferred_periods` không
- Nếu không → penalty += 1
- Weight=10 để ưu tiên hơn các ràng buộc khác (weight=1)

#### Tiến độ
| Bước | Mô tả | Trạng thái |
|------|--------|-----------|
| 1. Thêm field | `ScoreBreakdown.preference_violations` | ✅ |
| 2. Thêm field | `CBCTTInstance.teacher_preferred_periods` | ✅ |
| 3. Thêm method | `_compute_preference_violation(course_idx, period)` | ✅ |
| 4. Update insertion | `_insert_assignment()` thêm penalty | ✅ |
| 5. Update removal | `_remove_assignment()` trừ penalty | ✅ |
| 6. Update scoring | `score_breakdown()` return 6 fields | ✅ |
| 7. Update cost | `current_cost` property include preference_violations | ✅ |
| 8. Test & debug | Chạy thử, kiểm tra kết quả | 🔄 |

#### Tình trạng code
**algorithms_core.py (8 sửa):**
```python
# 1. ScoreBreakdown dataclass
@dataclass
class ScoreBreakdown:
    room_capacity: int = 0
    min_working_days: int = 0
    curriculum_compactness: int = 0
    room_stability: int = 0
    lecture_clustering: int = 0
    preference_violations: int = 0  # ✅ ĐÃ THÊM

    @property
    def total(self) -> int:
        return (self.room_capacity + self.min_working_days + 
                self.curriculum_compactness + self.room_stability + 
                self.lecture_clustering + self.preference_violations)  # ✅ ĐÃ THÊM

# 2. CBCTTInstance dataclass
@dataclass
class CBCTTInstance:
    ...
    teacher_preferred_periods: Dict[str, Set[int]] = field(default_factory=dict)  # ✅ ĐÃ THÊM

# 3. TimetableState method
def _compute_preference_violation(self, course_idx: int, period: int) -> int:
    """Check if period is in teacher's preferred periods"""
    teacher = self.instance.course_teachers[course_idx]
    preferred = self.instance.teacher_preferred_periods.get(teacher, set())
    return 0 if period in preferred else 1  # ✅ ĐÃ THÊM

# 4. _insert_assignment() thêm logic
pref_violation = self._compute_preference_violation(course_idx, period)
self.soft_preference_violations += pref_violation
delta += pref_violation * 10  # Weight = 10  # ✅ ĐÃ THÊM

# 5. _remove_assignment() thêm logic
old_pref_violation = self._compute_preference_violation(course_idx, period)
self.soft_preference_violations -= old_pref_violation
delta -= old_pref_violation  # ✅ ĐÃ THÊM

# 6. score_breakdown() return
return ScoreBreakdown(
    ...
    preference_violations=self.soft_preference_violations,  # ✅ ĐÃ THÊM
)

# 7. current_cost property
self.soft_preference_violations * self.WEIGHT_PREFERENCE_VIOLATIONS  # ✅ ĐÃ THÊM (weight=10)

# 8. TimetableState.__init__
self.soft_preference_violations = 0  # ✅ ĐÃ THÊM
```

**algorithms_data_adapter.py:**
```python
# Load NguyenVong preferences từ DB
teacher_available_periods: Dict[str, Set[int]] = {}
for vong in NguyenVong.objects.all():
    teacher_id = vong.giang_vien.id  # String
    period = vong.time_slot.id
    if teacher_id not in teacher_available_periods:
        teacher_available_periods[teacher_id] = set()
    teacher_available_periods[teacher_id].add(period)

# Pass to instance
teacher_preferred_periods=dict(teacher_available_periods)  # ✅ ĐÃ THÊM
```

---

## 🔧 Kỹ thuật chi tiết

### A. Cấu trúc dữ liệu chính

#### TimeSlot (35 slots)
```
Days: 0-6 (T2-CN)
Periods/day: 5 (Ca1-Ca5)
Total: 7 × 5 = 35

Chủ Nhật (CN): period 30-34
  → unavailability chặn 5 slot này
  → feasible_periods cho phép tất cả
```

#### NguyenVong Records (840)
```
Mapping: Teacher → TimeSlot (preferred)
Example: GV001 → [period 1, 5, 10, ...]
Purpose: Xác định khung giờ ưu tiên của GV
Current: ~125 vi phạm (lớp xếp ngoài khung)
```

#### Min_working_days
```
Constraint: Phân bổ lớp của GV qua ít nhất N ngày
Formula: 
  - Nếu active_days < min_days → penalty = (min_days - active_days)
  - Tính cho từng GV, từng khoa

Current: ~3240 penalty
  → Có ~3240 "ngày thiếu" trong toàn bộ lịch
```

### B. Thuật toán CB-CTT

**Quy trình:**
1. **Load data** từ DB
2. **Sắp xếp ưu tiên** lớp khó trước (GV dạy nhiều, ít periods)
3. **Backtracking:**
   - For each lecture (theo thứ tự ưu tiên):
     - For each candidate period:
       - For each candidate room:
         - Try place → check hard constraints
         - If valid → calculate soft penalties
         - If cost < best → try deeper
   - Random shuffle periods/rooms để tìm khác nhau
4. **Return** lời giải tốt nhất tìm được

**Độ phức tạp:**
- Worst case: 216 × 35 × 201 = 1.5M trạng thái
- Average case với pruning: ~8-10 giây

### C. Ràng buộc và Penalty

**Hard (check trước, nếu fail = bỏ qua):**
- Không xung đột (room, teacher, curriculum)
- Khả dụng GV (feasible_periods: cho phép tất cả 35 slots)
- Không học CN (unavailability: chặn period 30-34)

**Soft (tính penalty, tích lũy):**
```
total_cost = 1×room_capacity + 1×min_working_days + 1×curriculum_compactness 
           + 1×room_stability + 1×lecture_clustering + 10×preference_violations

Weight=1: Ràng buộc bình thường
Weight=10: Ưu tiên cao (NguyenVong preferences)
```

---

## 📈 Hiệu năng

### Kết quả chạy gần nhất

**Thời gian:**
```
Initialization: 0.37s
Total: Gần 10s (nếu có khởi tạo đầy đủ)
Status: ✅ SUCCESS
```

**Lịch biểu:**
```
216/216 lectures assigned
All hard constraints satisfied
Penalty breakdown:
  - room_capacity: 0 (✅ fit)
  - min_working_days: ~3240 (⚠️ còn phân bổ)
  - curriculum_compactness: ~14 (✅ tốt)
  - room_stability: 0 (✅ fit)
  - lecture_clustering: 0 (✅ fit)
  - preference_violations: ~125 → ? (🔄 kiểm tra)
```

### Top 10 GV "khó nhất" (xếp trước)
```
1. GV004 - 15 lớp, 35 periods, ratio=0.43
2. GV004 - (lặp)
...
10. GV004 - (lặp)
```
→ GV004 là "bottleneck", dạy 15 lớp = 43% capacity

---

## 📋 Kế hoạch tiếp theo

### Ngay lập tức (Priority: 🔴 HIGH)
1. **Test preference_violations** 
   - Chạy `test_algo.py`
   - Kiểm tra output: preference_violations có < 125 không?
   - Debug nếu có lỗi

2. **Kiểm tra score_breakdown**
   - Verify `score_breakdown()` return 6 fields
   - Check tổng cost có hợp lý không

3. **Xác thực behavior**
   - Validate hard constraints vẫn satisfied
   - Check JSON output format

### Tuần này (Priority: 🟡 MEDIUM)
4. **Tối ưu weight**
   - Test weight=5, 10, 20, 50
   - Tìm weight tối ưu giảm max violations

5. **Phân tích violations**
   - Breakdown: Violations per teacher
   - Tìm GV nào nhiều violations nhất
   - Tìm periods nào thiếu assignments

6. **Cải thiện heuristic**
   - Sort candidates theo preference_violations count
   - Thử prioritize preferred periods trước

### Tuần sau (Priority: 🟢 LOW)
7. **Tối ưu min_working_days**
   - Analyze: Nếu min_working_days quá cao thì tuân thủ?
   - Tính toán min_working_days tối thiểu khả thi

8. **Document & Review**
   - Viết design document
   - Code review, refactor
   - Prepare final report

---

## 📝 Ghi chú kỹ thuật

### Lịch sử Bug Fix
| Bug | Commit | Chi tiết |
|-----|--------|---------|
| GV004 infeasible | Day 1 | Feasible_periods quá ít → cho phép tất cả |
| "Thu0" sai | Day 2 | day_idx=0 không convert → thêm +2 |
| Cùng kết quả mỗi lần | Day 3 | seed=42 → random.randint(1, 1M) |
| Preference violations tracking | Day 4 | Implement complete → 8 sửa |

### Quyết định thiết kế
1. **feasible_periods = all slots** (không bị NguyenVong giới hạn)
   - Reason: GV004 có 15 lớp nhưng chỉ 13 NguyenVong slots → infeasible
   - Solution: Cho phép tất cả, dùng soft penalty thay vì hard constraint

2. **unavailability = chỉ Chủ Nhật** (hard block)
   - Reason: Quy định: không học Chủ Nhật
   - Solution: Block 5 period Chủ Nhật (30-34)

3. **preference_violations weight = 10** (hơn weight=1 của các ràng buộc khác)
   - Reason: NguyenVong là yêu cầu quan trọng từ GV
   - Solution: Tăng weight để tối ưu hóa violations trước

4. **Heuristic order = khó trước**
   - Reason: GV dạy nhiều (ratio cao), ít periods → khó xếp
   - Solution: Sort theo `ratio = lectures/periods`, giảm dần

---

## 📊 Thống kê

### Dữ liệu hiện tại
```
Total lectures: 216
Total courses: 216 (1:1)
Total rooms: 201 (1-dung trong số cases)
Total timeslots: 35 (7 days × 5 periods)
Total teachers: 36
Total curriculums: 36
Total NguyenVong records: 840

Teachers per course: 1
Courses per teacher: ~6 (216/36)
NguyenVong preferences per teacher: ~23 (840/36)
  → Mỗi GV có ~23 preferred periods (out of 35)
  → Coverage: 65% (23/35)
```

### Xung đột tiềm năng
```
Curriculum conflicts: 36 (1 per curriculum)
Rooms utilization: ~107% (216/201)
  → Phòng bận, có overlapping → cần xếp sáng tạo

Min_working_days: 4-5 (depending on teacher)
  → Các GV dạy 4-5 ngày/tuần
```

---

## 🎓 Học được từ dự án

1. **Constraint satisfaction**: Phân biệt hard vs soft constraints
2. **Backtracking**: Hiệu quả với pruning & heuristic ordering
3. **Randomization**: Random seed giúp tìm multiple solutions
4. **Penalty weights**: Trọng số phản ánh ưu tiên optimization
5. **Django ORM**: Query optimization, indexing quan trọng
6. **Logging**: Debug output giúp hiểu thuật toán

---

## ✉️ Liên hệ & Q&A

**Hỏi:** Tại sao preference_violations = 125?
**Trả lời:** 125 lớp được xếp ngoài khung giờ ưu tiên của GV. Có thể do:
- GV không có đủ preferred periods
- Conflict với constraint khác (hard)
- Heuristic chưa optimal

**Hỏi:** Có thể giảm xuống 0 không?
**Trả lời:** Phụ thuộc vào độ khả thi. Nếu feasible_periods quá ít sẽ conflict. Mục tiêu: < 50 violations.

**Hỏi:** min_working_days = 3240 là bao nhiêu?
**Trả lời:** ~600 GV-days bị thiếu (3240/36 ≈ 90 days bình quân). Ý nghĩa: GV dạy trên ít hơn ngày cần.

---

**Status:** 🟡 IN PROGRESS - Giai đoạn 4 (Tối ưu) ~75% complete
**Deadline tiếp theo:** Test & debug preference_violations (24h)
**Người chịu trách nhiệm:** Dev Team
**Cập nhật lần cuối:** 27/10/2025 - 16:30

