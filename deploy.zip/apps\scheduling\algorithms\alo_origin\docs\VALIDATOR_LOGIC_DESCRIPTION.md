# 📋 VALIDATOR.PY - CHI TIẾT LOGIC KIỂM TRA

## 📊 TÓMING TẮT

Validator kiểm tra **12 ràng buộc** bao gồm:
- **6 ràng buộc CỨNG (Hard Constraints)**: HC-01 to HC-06 (6 violations)
- **6 ràng buộc MỀM (Soft Constraints)**: S1 to S8 (cost-based)

---

## 🔴 HARD CONSTRAINTS (H1-H6) - Violations

### **H1: Lecture Count (Số lượng lớp được phân công trong đợt)**
- **Check**: `costs_on_lectures()`
- **Logic**:
  ```
  Mỗi khóa học phải được xếp ĐÚNG SỐ lớp trong phân công
  - Nếu lớp xếp < lớp cần: violations += (cần - xếp)
  - Nếu lớp xếp > lớp cần: violations += (xếp - cần)
  ```
- **Ví dụ**: Đợt học yêu cầu 216 lớp nhưng chỉ xếp 215 lớp → violations += 1

---

### **H2: Course Conflicts (Khóa học xung đột)**
- **Check**: `costs_on_conflicts()`
- **Logic**:
  ```
  Các khóa học XUNG ĐỘT không được xếp cùng 1 PERIOD
  Xung đột xảy ra khi:
  1. Hai khóa học cùng 1 giảng viên
  2. Hai khóa học cùng 1 môn học 
  
  Cách kiểm tra:
  - Với mỗi cặp khóa học (c1, c2) có xung đột
  - Nếu cùng period p: xếp(c1,p) != 0 AND xếp(c2,p) != 0
    → violations += 1
  ```
- **Ví dụ**: GV001 dạy cả LOP-00001 và LOP-00002 (cùng giáo viên)
  - Nếu đặt cả 2 vào ca học (Thu 2, Ca 1) → violations += 1

---

### **H3: Unavailability Constraints (Slot không khả dụng)**
- **Check**: `costs_on_availability()`
- **Logic**:
  ```
  Khóa học KHÔNG được xếp vào slot không khả dụng
  
  Cách kiểm tra:
  - Với mỗi khóa học c
  - Nếu availability[c][p] = False và xếp(c,p) != 0
    → violations += 1
  ```
- **Ví dụ**: GV001 không có mặt T2 Ca1 nhưng vẫn xếp LOP-00001 vào slot đó
  → violations += 1

---

### **H4: Room Capacity (Sức chứa phòng)**
- **Check**: `costs_on_room_occupation()`
- **Logic**:
  ```
  Một phòng chỉ được xếp TỐI ĐA 1 khóa học tại 1 period
  
  Cách kiểm tra:
  - Với mỗi room r, mỗi period p
  - Nếu room_lectures[r][p] > 1
    → violations += (room_lectures[r][p] - 1)
  ```
- **Ví dụ**: Phòng A201 có 2 khóa học cùng xếp T2 Ca1 (room_lectures[A201][p] = 2)
  → violations += 1

---

### **H5: Room Type Matching (Loại phòng phù hợp) - EXTENDED**
- **Check**: `costs_on_room_type()`
- **Logic**:
  ```
  Loại khóa học phải KHỚP loại phòng
  - Khóa học LT (Lý thuyết) → phòng LT
  - Khóa học TH (Thực hành) → phòng TH
  
  Cách kiểm tra:
  - Với mỗi khóa học c có course_type
  - Nếu xếp(c,p) != 0
    - room_type = room[xếp(c,p)].type
    - Nếu room_type != course_type
      → violations += 1
  ```
- **Ví dụ**: LOP-00001 (LT) xếp vào phòng A201 (TH) → violations += 1

---

### **H6: Equipment Requirements (Thiết bị yêu cầu) - EXTENDED**
- **Check**: `costs_on_equipment()`
- **Logic**:
  ```
  Phòng phải có ĐỦ thiết bị mà khóa học yêu cầu
  
  Cách kiểm tra:
  - Với mỗi khóa học c có equipment_required
  - Nếu xếp(c,p) != 0
    - equipment_room = room[xếp(c,p)].equipment
    - missing = equipment_required - equipment_room
    - Nếu missing != ∅
      → violations += 1
  ```
- **Ví dụ**: LOP-00001 yêu cầu "TV, Máy chiếu" nhưng phòng A201 chỉ có "PC"
  → violations += 1 (thiếu TV, Máy chiếu)

---

## 🟡 SOFT CONSTRAINTS (S1-S8) - Costs

### **S1: Room Capacity (Sức chứa phòng - Soft)**
- **Check**: `costs_on_room_capacity()`
- **Logic**:
  ```
  Phòng NÊN có sức chứa ≥ số sinh viên khóa học
  Nếu không đủ chỗ:
  - cost += (num_students - room_capacity)
  
  Cách kiểm tra:
  - Với mỗi khóa học c, mỗi period p
  - Nếu xếp(c,p) != 0
    - shortage = course.students - room.capacity
    - Nếu shortage > 0
      → cost += shortage
  ```
- **Ví dụ**: Khóa LOP-00001 có 80 SV xếp vào phòng A201 (40 chỗ)
  - cost += (80 - 40) = 20

---

### **S2: Minimum Working Days (Ngày học tối thiểu - Soft)**
- **Check**: `costs_on_min_working_days()`
- **Logic**:
  ```
  Các tiết của khóa học NÊN phân bố trên NHIỀU ngày
  - min_working_days = số ngày tối thiểu yêu cầu
  - working_days = số ngày thực tế có tiết học
  - Nếu working_days < min_working_days
    → cost += (min_working_days - working_days)
  
  Công thức min_working_days (từ data adapter):
  - Nếu so_ca_tuan > 2: min_working_days = 2
  - Nếu so_ca_tuan ≤ 2: min_working_days = 1
  
  Cost weight: 5
  ```
- **Ví dụ**: LOP-00001 (4 tiết) cần phân bố trên 2 ngày
  - Nếu xếp tất cả 4 tiết vào T2 → cost += (2 - 1) * 5 = 5

---

### **S3: Curriculum Compactness (Cơ cấu ngành liên tục - Soft)**
- **Check**: `costs_on_curriculum_compactness()`
- **Logic**:
  ```
  Các tiết của cùng 1 MÔN NÊN được xếp liền kề (không cách nhau)
  
  Để tìm "tiết cô lập" (isolated lecture):
  - Tiết ở đầu ngày: CÁCH LẬP nếu tiết tiếp theo (p+1) không có khóa học
  - Tiết ở cuối ngày: CÁCH LẬP nếu tiết trước (p-1) không có khóa học
  - Tiết ở giữa: CÁCH LẬP nếu cả (p-1) và (p+1) không có khóa học
  
  Cost:
  - Với mỗi tiết cô lập của ngành: cost += 1 * (số tiết cô lập)
  
  Cost weight: 2
  ```
- **Ví dụ**: Ngành có tiết ở Ca 1 và Ca 3 nhưng Ca 2 trống
  - Tiết Ca 3 CÁCH LẬP (Ca 2 và Ca 4 trống) → cost += 1 * 2 = 2

---

### **S4: Room Stability (Ổn định phòng học - Soft)**
- **Check**: `costs_on_room_stability()`
- **Logic**:
  ```
  Khóa học NÊN sử dụng CÙNG 1 phòng cho tất cả tiết
  
  Cách kiểm tra:
  - Với mỗi khóa học c
  - used_rooms = số phòng khác nhau được dùng
  - Nếu used_rooms > 1
    → cost += (used_rooms - 1)
  
  Cost weight: 1
  ```
- **Ví dụ**: LOP-00001 xếp tiết 1 vào A201, tiết 2 vào A202
  - used_rooms = 2 → cost += (2 - 1) * 1 = 1

---

### **S5: Lecture Consecutiveness (Tiết học liên tiếp - Soft)**
- **Check**: `costs_on_lecture_consecutiveness()`
- **Logic**:
  ```
  QUYẾT MỚI: Các tiết của khóa học NÊN được xếp LIÊN TỤC (2 tiết cạnh nhau)
  
  Quy tắc phân loại theo số tiết:
  
  📌 2 TIẾT: Phải LIÊN TỤC (cạnh nhau)
    - Nếu không: cost += 5
  
  📌 3 TIẾT: Phải có 1 CẶP LIÊN TỤC
    - 3 tiết riêng lẻ: cost += 8
    - 1 cặp nhưng cùng ngày: cost += 20
  
  📌 4 TIẾT: Phải có 2 CẶP LIÊN TỤC
    - < 2 cặp: cost += (2 - pairs) * 8
    - 2 cặp nhưng cùng ngày: cost += 15
  
  📌 ≥ 5 TIẾT:
    - < 2 cặp: cost += (2 - pairs) * 6
    - Cặp trên < 2 ngày: cost += 8
  
  📌 PHẠT ĐẶC BIỆT: Tất cả tiết cùng 1 ngày (≥3 tiết)
    - cost += 30 (rất nặng)
  
  Ví dụ cách tính "cặp":
    - Tiết 1, Tiết 2 (liên tiếp): 1 cặp ✓
    - Tiết 1, Tiết 2, Tiết 3 (liên tiếp): 1 cặp + 1 lẻ
  ```
- **Ví dụ 1**: LOP-00001 (3 tiết) xếp T2 Ca1, T2 Ca2, T2 Ca3
  - Cặp: (Ca1, Ca2) = 1 cặp
  - Tất cả cùng ngày (T2) và ≥3 tiết → cost += 30
  
- **Ví dụ 2**: LOP-00001 (2 tiết) xếp T2 Ca1, T3 Ca1 (không liên tiếp)
  - 0 cặp → cost += 5

---

### **S6: Teacher Lecture Consolidation (Gom tiết giáo viên cùng phòng) - EXTENDED**
- **Check**: `costs_on_teacher_lecture_consolidation()`
- **Logic**:
  ```
  GV NÊN giảng dạy LIÊN TIẾP trong CÙNG 1 PHÒNG
  (Tránh dạy xong T2 phòng A1, rồi T2 phòng A2 - phải chuyển phòng)
  
  ⭐ QUAN TRỌNG: CHỈ penalize khi course_type GIỐNG NHAU
  - Nếu GV dạy LT (LT room) rồi TH (TH room): NO PENALTY
    (bắt buộc phải đổi phòng vì loại khác nhau)
  - Nếu GV dạy LT rồi LT ở phòng khác: PENALTY
    (không cần phải đổi phòng)
  
  Cách kiểm tra:
  - Gom tất cả tiết theo giáo viên
  - Sắp xếp theo (day, period)
  - Với mỗi cặp tiết LIÊN TIẾP trên cùng ngày:
    - Nếu room1 != room2 AND course_type1 == course_type2
      → cost += 1
  
  Cost weight: 1.8 (ƯU TIEN CAO)
  ```
- **Ví dụ 1**: GV001 dạy
  - T2 Ca1: LOP-00001 (LT) phòng B201
  - T2 Ca2: LOP-00004 (LT) phòng B202
  - course_type = LT = LT (cùng loại) → cost += 1

- **Ví dụ 2**: GV003 dạy
  - T2 Ca1: LOP-00002 (TH) phòng A201
  - T2 Ca2: LOP-00032 (LT) phòng B201
  - course_type = TH ≠ LT (khác loại) → NO PENALTY ✓

---

### **S7: (KHÔNG SỬ DỤNG)**
- Không có S7 trong logic

---

### **S8: Teacher Preferences (Nguyện vọng giáo viên) - EXTENDED**
- **Check**: `costs_on_teacher_preferences()`
- **Logic**:
  ```
  GV NÊN dạy vào các SLOT MONG MUỐN
  
  Định dạng dữ liệu PREFERENCES:
  - teacher_id day period_in_day
  - Ví dụ: GV001 0 4
    (GV001 mong muốn T2 Ca 5)
  
  Cách kiểm tra:
  - Với mỗi khóa học c
  - teacher = course[c].teacher
  - preferred_slots = preferences.get(teacher, ∅)
  - Nếu preferred_slots rỗng: no cost (không có preference)
  - Với mỗi tiết của c
    - slot = (day, period_in_day)
    - Nếu slot NOT in preferred_slots
      → cost += 1
  
  Cost weight: 2.0 (ƯUTIEN CAO NHẤT)
  ```
- **Ví dụ**: GV001 mong muốn dạy (T2 Ca1), (T3 Ca2)
  - Nếu xếp LOP-00001 vào T4 Ca1 (không mong muốn) → cost += 1

---

## 📈 CÔNG THỨC TÍNH TỔNG COST

```
TOTAL VIOLATIONS (Hard Constraints):
  = H1 + H2 + H3 + H4 + H5 + H6

TOTAL COST (Soft + Hard):
  = S1_room_capacity
  + S2_min_working_days * 5
  + S3_curriculum_compactness * 2
  + S4_room_stability * 1
  + S5_lecture_consecutiveness
  + S6_teacher_lecture_consolidation * 1.8
  + S8_teacher_preferences * 2.0
  
  (Lưu ý: S1 KHÔNG nhân weight, các S khác nhân weight)
```

---

## ✅ KIỂM TRA ĐẦY ĐỦ?

| Constraint | Hard/Soft | Checked | Logic | Note |
|-----------|-----------|---------|-------|------|
| H1 Lecture count | Hard | ✅ | Đếm tiết xếp vs tiết cần | OK |
| H2 Conflicts | Hard | ✅ | GV xung đột + Ngành xung đột | OK |
| H3 Availability | Hard | ✅ | Kiểm tra availability matrix | OK |
| H4 Room occupation | Hard | ✅ | Phòng max 1 khóa học/period | OK |
| H5 Room type | Hard | ✅ | LT↔LT, TH↔TH | ✅ Extended |
| H6 Equipment | Hard | ✅ | Course equipment ⊆ Room equipment | ✅ Extended |
| S1 Room capacity | Soft | ✅ | Không nhân weight, tính trực tiếp | OK |
| S2 Min working days | Soft | ✅ | Phân bố trên nhiều ngày | OK |
| S3 Curriculum compactness | Soft | ✅ | Tiết liên kề trong môn | OK |
| S4 Room stability | Soft | ✅ | Cùng 1 phòng | OK |
| S5 Lecture consecutiveness | Soft | ✅ | Quy tắc cặp tiết riêng | OK |
| S6 Teacher consolidation | Soft | ✅ | GV dạy liên tiếp cùng phòng + **same type check** | ✅ Extended + ✅ Fixed |
| S7 - | - | - | Không có | - |
| S8 Teacher preferences | Soft | ✅ | Dạy đúng slot mong muốn | ✅ Extended |

---

## 🔍 KẾT LUẬN

**✅ VALIDATOR ĐÃ KIỂM TRA ĐẦY ĐỦ TẤT CẢ CÁC RÀNG BUỘC:**
- 6 Hard constraints (violations)
- 8 Soft constraints (costs) - bao gồm 2 constraint mở rộng (HC-04, HC-05/06, S6, S8)

**🎯 ĐẶC ĐIỂM CỦA VALIDATOR:**
1. ✅ Kiểm tra loại phòng (LT/TH) - EXTENDED
2. ✅ Kiểm tra thiết bị phòng - EXTENDED
3. ✅ Kiểm tra nguyện vọng GV - EXTENDED
4. ✅ Kiểm tra **CHÍNH XÁC** teacher consolidation (CHỈ penalize same-type)
5. ✅ Tính cost theo weight constants đúng cách

**⚠️ LƯU Ý:**
- S1 (Room capacity) là soft constraint nhưng **KHÔNG NHÂN WEIGHT** (tính direct overhead)
- Các soft constraint khác nhân weight rồi cộng vào total_cost
- Logic teacher consolidation đã sửa để chỉ penalize khi course_type GIỐNG NHAU

