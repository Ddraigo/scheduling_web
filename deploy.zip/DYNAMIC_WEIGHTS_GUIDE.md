# Hướng Dẫn Sử Dụng Dynamic Soft Constraint Weights

## Tổng Quan

Hệ thống đã được nâng cấp để hỗ trợ **trọng số ràng buộc mềm động** (Dynamic Soft Constraint Weights):

- ✅ **Linh hoạt**: Trọng số được load từ database theo từng đợt xếp lịch
- ✅ **An toàn**: Tự động fallback sang trọng số mặc định nếu database trống/lỗi
- ✅ **Không crash**: Đảm bảo solver luôn hoạt động trong mọi trường hợp

---

## Kiến Trúc

### 1. Các Bảng Database

#### **tb_RANG_BUOC_MEM** (Ràng buộc mềm)
```sql
MaRangBuoc (PK)    TenRangBuoc                          TrongSo  MoTa
-----------------  -----------------------------------  -------  -----
RB_MIN_WORKING_DAYS            Số ngày làm việc tối thiểu         1.0
RB_LECTURE_CONSECUTIVENESS     Tiết học liên tiếp                 1.5
RB_ROOM_STABILITY              Ổn định phòng học                  1.0
RB_TEACHER_CONSOLIDATION       GV dạy liên tiếp cùng phòng        1.8
RB_TEACHER_PREFERENCE          Nguyện vọng giảng viên             2.0
RB_TEACHER_WORKING_DAYS        Tối thiểu ngày lên trường GV       2.5
RB_ROOM_CAPACITY               Sức chứa phòng học                 1.0
```

#### **tb_RANG_BUOC_TRONG_DOT** (Ràng buộc áp dụng cho đợt)
```sql
ID (PK)  MaDot           MaRangBuoc
-------  --------------  --------------------------
1        DOT-2024-HK1    RB_TEACHER_PREFERENCE
2        DOT-2024-HK1    RB_TEACHER_WORKING_DAYS
3        DOT-2024-HK2    RB_MIN_WORKING_DAYS
```

### 2. Logic Load Trọng Số

```
Gọi: WeightLoader.load_weights(ma_dot='DOT-2024-HK1')

Step 1: Có ma_dot?
    YES → Tìm trong tb_RANG_BUOC_TRONG_DOT
          ├─ Có records? → Load weights từ đó
          └─ Không có? → Go to Step 2
    NO → Go to Step 2

Step 2: Load global defaults
    → Lấy tất cả từ tb_RANG_BUOC_MEM
    └─ Bảng trống? → Go to Step 3

Step 3: Fallback to hardcoded DEFAULT_WEIGHTS
    → Trả về trọng số mặc định trong code

Result: Dict[str, float]
    {
        'MIN_WORKING_DAYS': 1.0,
        'TEACHER_PREFERENCE': 2.0,
        ...
    }
```

---

## Sử Dụng

### 1. Seed Data Mặc Định

Chạy script seed để tạo dữ liệu mẫu:

```bash
python manage.py shell < apps/scheduling/migrations/seed_rang_buoc_mem.py
```

Hoặc trong Django shell:

```python
from apps.scheduling.migrations.seed_rang_buoc_mem import seed_rang_buoc_mem
seed_rang_buoc_mem()
```

### 2. Quản Lý Ràng Buộc Mềm (Admin)

#### **Xem/Sửa Trọng Số Toàn Cục**
1. Đăng nhập Admin: `/admin/`
2. Vào **Scheduling > Ràng buộc mềm**
3. Click vào constraint để chỉnh sửa `TrongSo`
4. Save

#### **Cấu Hình Cho Từng Đợt**
1. Vào **Scheduling > Ràng buộc trong đợt**
2. Click "Add Ràng buộc trong đợt"
3. Chọn `MaDot` (ví dụ: DOT-2024-HK1)
4. Chọn `MaRangBuoc` (ví dụ: RB_TEACHER_PREFERENCE)
5. Save

**Lưu ý**: Chỉ cần thêm những ràng buộc bạn muốn **override** cho đợt đó. Các ràng buộc không có sẽ dùng global defaults.

### 3. Sử Dụng Trong Code

#### **Trong Solver (Tự động)**

Solver đã tự động sử dụng trọng số động:

```python
from apps.scheduling.algorithms.algorithms_core import TimetableState, parse_instance

# Load instance
instance = parse_instance("path/to/instance.txt")

# Tạo state với ma_dot
state = TimetableState(instance, ma_dot='DOT-2024-HK1')

# Weights đã được load tự động
# state.weights = {'MIN_WORKING_DAYS': 1.0, 'TEACHER_PREFERENCE': 2.5, ...}

# Tính cost sẽ dùng self.weights[] thay vì hardcoded constants
cost = state.current_cost
```

#### **Load Weights Riêng Lẻ**

```python
from apps.scheduling.algorithms.weight_loader import WeightLoader

# Load cho đợt cụ thể
weights = WeightLoader.load_weights('DOT-2024-HK1')
print(weights)
# {'MIN_WORKING_DAYS': 1.0, 'TEACHER_PREFERENCE': 2.5, ...}

# Load global defaults (không chỉ định đợt)
weights = WeightLoader.load_weights()

# Lấy một trọng số cụ thể
weight = WeightLoader.get_weight('TEACHER_PREFERENCE', 'DOT-2024-HK1')
print(weight)  # 2.0
```

---

## Test

### Chạy Test Suite

```bash
python -m apps.scheduling.algorithms.test_weight_loader
```

**Kết quả mong đợi:**
```
############################################################
# WEIGHT LOADER TEST SUITE
############################################################

============================================================
TEST 1: Default Weights Structure
============================================================
✅ DEFAULT_WEIGHTS structure is valid
   LECTURE_CONSECUTIVENESS: 1.5
   MIN_WORKING_DAYS: 1.0
   ...

============================================================
TEST 2: Load Global Defaults (no ma_dot)
============================================================
✅ Loaded 7 global weights:
   ...

============================================================
# ALL TESTS PASSED ✅
############################################################
```

---

## Ví Dụ Thực Tế

### Scenario 1: Đợt xếp lịch mới (không có custom constraints)

```python
# Admin không tạo RangBuocTrongDot cho DOT-2024-HK1

weights = WeightLoader.load_weights('DOT-2024-HK1')
# → Load từ tb_RANG_BUOC_MEM (global defaults)
# → weights = {'MIN_WORKING_DAYS': 1.0, 'TEACHER_PREFERENCE': 2.0, ...}
```

### Scenario 2: Đợt xếp đặc biệt (tăng priority cho nguyện vọng GV)

**Bước 1**: Admin thêm vào `tb_RANG_BUOC_TRONG_DOT`:
```sql
INSERT INTO tb_RANG_BUOC_TRONG_DOT (MaDot, MaRangBuoc)
VALUES ('DOT-2024-HK1', 'RB_TEACHER_PREFERENCE');
```

**Bước 2**: Sửa trọng số trong `tb_RANG_BUOC_MEM`:
```sql
UPDATE tb_RANG_BUOC_MEM
SET TrongSo = 3.0
WHERE MaRangBuoc = 'RB_TEACHER_PREFERENCE';
```

**Bước 3**: Load weights
```python
weights = WeightLoader.load_weights('DOT-2024-HK1')
# → weights['TEACHER_PREFERENCE'] = 3.0 (override)
# → weights['MIN_WORKING_DAYS'] = 1.0 (global default)
```

### Scenario 3: Database bị xóa nhầm

```python
# Admin xóa tất cả records trong tb_RANG_BUOC_MEM

weights = WeightLoader.load_weights('DOT-2024-HK1')
# → Fallback to DEFAULT_WEIGHTS
# → weights = {'MIN_WORKING_DAYS': 1.0, 'TEACHER_PREFERENCE': 2.0, ...}
# ✅ Solver vẫn chạy bình thường!
```

---

## Troubleshooting

### 1. Weights không thay đổi sau khi sửa database

**Nguyên nhân**: Có thể có cache hoặc bạn đang xem đợt khác

**Giải pháp**:
```python
# Force reload
from django.core.cache import cache
cache.clear()

# Check weights
weights = WeightLoader.load_weights('DOT-2024-HK1')
print(weights)
```

### 2. ImportError: cannot import WeightLoader

**Nguyên nhân**: Chạy algorithms_core.py standalone (không có Django)

**Giải pháp**: Đảm bảo weight_loader.py trong cùng folder. Nếu standalone, có fallback tự động:
```python
# algorithms_core.py có fallback:
try:
    from .weight_loader import WeightLoader
except ImportError:
    # Tự động dùng hardcoded defaults
    class WeightLoader:
        @staticmethod
        def load_weights(ma_dot=None):
            return DEFAULT_WEIGHTS.copy()
```

### 3. Solver crash với "KeyError: 'TEACHER_PREFERENCE'"

**Nguyên nhân**: Database trả về constraint không có trong CONSTRAINT_MAPPING

**Giải pháp**: Kiểm tra `ma_rang_buoc` trong database phải match với CONSTRAINT_MAPPING:
```python
# weight_loader.py
CONSTRAINT_MAPPING = {
    'RB_MIN_WORKING_DAYS': 'MIN_WORKING_DAYS',
    'RB_TEACHER_PREFERENCE': 'TEACHER_PREFERENCE',
    # ...
}
```

Nếu thêm constraint mới trong database, phải cập nhật CONSTRAINT_MAPPING.

---

## API Reference

### `WeightLoader.load_weights(ma_dot=None)`

**Tham số**:
- `ma_dot` (str, optional): Mã đợt xếp lịch (ví dụ: 'DOT-2024-HK1')

**Trả về**:
- `Dict[str, float]`: Dict chứa trọng số cho tất cả constraints

**Hành vi**:
- Nếu `ma_dot` không None: Tìm trong `tb_RANG_BUOC_TRONG_DOT`
- Nếu không tìm thấy: Fallback sang `tb_RANG_BUOC_MEM`
- Nếu database lỗi/trống: Fallback sang `DEFAULT_WEIGHTS`

**Ví dụ**:
```python
weights = WeightLoader.load_weights('DOT-2024-HK1')
# {'MIN_WORKING_DAYS': 1.0, 'TEACHER_PREFERENCE': 2.0, ...}
```

### `WeightLoader.get_weight(constraint_name, ma_dot=None)`

**Tham số**:
- `constraint_name` (str): Tên constraint (ví dụ: 'TEACHER_PREFERENCE')
- `ma_dot` (str, optional): Mã đợt xếp lịch

**Trả về**:
- `float`: Trọng số của constraint

**Ví dụ**:
```python
weight = WeightLoader.get_weight('TEACHER_PREFERENCE', 'DOT-2024-HK1')
# 2.0
```

---

## Migration Checklist

Khi nâng cấp code từ bản cũ:

- [x] Import WeightLoader trong algorithms_core.py
- [x] Thêm `ma_dot` parameter vào `TimetableState.__init__()`
- [x] Load `self.weights` trong `__init__()`
- [x] Replace tất cả `WEIGHT_*` constants bằng `self.weights['...']`
- [x] Seed data cho `tb_RANG_BUOC_MEM`
- [x] Test với database trống (verify failsafe)
- [x] Test với custom dot constraints
- [x] Update documentation

---

## Lợi Ích

### Trước (Hardcoded)
```python
# algorithms_core.py
WEIGHT_TEACHER_PREFERENCE = 2.0  # Cố định

# Muốn thay đổi?
# → Phải sửa code
# → Phải restart server
# → Không thể customize cho từng đợt
```

### Sau (Dynamic)
```python
# Admin interface
# Vào /admin/scheduling/rangbuocmem/
# Sửa TrongSo = 3.0
# Save

# Solver tự động dùng trọng số mới
# ✅ Không cần restart server
# ✅ Không cần sửa code
# ✅ Có thể customize cho từng đợt
```

---

## Kết Luận

Hệ thống dynamic weights giúp:

1. **Linh hoạt**: Admin có thể điều chỉnh trọng số qua UI
2. **An toàn**: Luôn có fallback, không bao giờ crash
3. **Scalable**: Dễ dàng thêm constraints mới
4. **Maintainable**: Tách biệt config và logic

**Best Practice**:
- Seed DEFAULT_WEIGHTS vào database ngay từ đầu
- Chỉ override weights khi thật sự cần thiết
- Test kỹ với database trống để verify failsafe
